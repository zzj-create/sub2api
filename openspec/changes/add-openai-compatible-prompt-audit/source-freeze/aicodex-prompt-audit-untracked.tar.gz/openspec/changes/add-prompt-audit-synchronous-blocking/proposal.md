## Why

当前“提示词安全审计”只在主请求继续转发后异步调用 Guard，审计结果中的 `Block` 仅用于事后记录，不能阻止请求访问上游。管理员需要在现有页面底部保存栏中显式开启“同步阻止”，让已纳入审计范围的提示词在计费与上游转发前完成安全判定；未开启时必须完整保留当前异步只审计行为。

## What Changes

- 在提示词审计配置中新增 `blocking_enabled`，并在截图红框所示的底部保存栏中增加“同步阻止”开关，位置与“启用审计”“保留通过事件”并列。
- 明确双模式语义：
  - `enabled=true` 且 `blocking_enabled=false`：保持现有异步投递、worker 扫描和事后审计，不改变主模型请求结果。
  - `enabled=true` 且 `blocking_enabled=true`：对适用分组和支持的协议执行同步 Guard；只有安全判定允许后才可进入渠道选择、计费预扣和上游转发。
  - `enabled=false`：不执行新的异步审计或同步阻止，`blocking_enabled` 的运行时有效值必须为 `false`。
- 同步模式下，Guard 返回 `Block` 时使用稳定的协议错误阻止请求；Guard 超时、不可用或响应非法时采用 fail-closed，返回可区分的服务不可用错误，不得静默放行。
- 同步模式复用现有协议输入提取、Qwen3Guard 扫描、Unicode 分片和结果归一化能力，但同步结果必须直接驱动服务端策略，且不得再异步重复调用 Guard。
- 同步阻止必须覆盖 `6068` 与 `9068` 的 OpenAI Chat/Responses、Claude Messages、Gemini 和已支持文本任务入口；Responses WebSocket 必须在首轮及后续每轮帧的计费与上游发送前执行门禁。
- 为阻止、允许、失败、配置变更和运行态增加结构化日志与指标，记录稳定的 `request_id`、策略版本、判定、耗时和错误码，禁止记录原始提示词、API Key 或 Guard Token。
- 收紧阻断关键路径的 Guard 响应解析、端点访问和调度语义：非法或不确定结果不得当作安全结果；同步模式只使用明确的优先级故障切换，不再接受前后端不一致或静默降级的调度策略。
- 保留现有脱敏审计事件与控制台复核能力；同步判定结果通过不含原始提示词的记录路径复用到审计事件，避免重复扫描。
- 增加灰度与回滚路径：先在关闭“同步阻止”时观察候选阻断结果，再按选定分组启用；关闭该开关即可立即回到原有异步只审计模式，无需回滚数据库。

目标：

- 让管理员通过一个明确开关选择“异步只审计”或“同步审计并阻止”。
- 保证被阻止请求不会访问上游、不会发生预扣费、不会进入渠道重试。
- 保证 `6068`、`9068`、HTTP、SSE 与 Responses WebSocket 的执行语义一致。
- 保证同步关键路径可观测、可回滚、可灰度且不泄露提示词正文。

非目标：

- 不实现模型输出内容的响应侧审核。
- 不实现提示词自动改写或 `Redact` 后继续转发。
- 不引入人工审批流或按单条请求临时确认。
- 不修改 HTTP 安全审计页面和规则语义。
- 不把普通通用大模型扩展为新的 Guard 协议；本变更继续使用现有 OpenAI 兼容 Qwen3Guard 契约。

## Capabilities

### New Capabilities

- `prompt-input-guard`: 定义提示词同步门禁、阻止判定、fail-closed、协议错误、计费与上游副作用边界、Responses WebSocket 帧级阻止和结构化观测契约。

### Modified Capabilities

- `prompt-input-audit`: 将现有异步只审计契约扩展为受 `blocking_enabled` 控制的双模式，并补充控制台开关、同步结果复用、运行态与回滚要求。

## Impact

- 控制台：`webui/src/features/prompt-audit/`、`webui/src/types/promptAudit.ts`、`webui/src/api/promptAudit.ts` 和对应测试；不修改已弃用的 `web/`。
- 控制面：提示词审计配置 API、配置校验、版本与运行态响应；沿用现有配置存储，默认不新增数据库表。
- 网关边界与数据面：`ai-gateway/internal/gatewaycore/`、`ai-gateway/internal/gatewayadapter/transport/`、OpenAI/Claude/Gemini relay 编排及 Responses WebSocket 帧处理；同步门禁必须位于渠道选择、计费和上游发送之前。
- 审计服务：`ai-gateway/internal/service/promptaudit/` 的输入快照、Guard 客户端、结果归一化、结果记录和日志；异步模式保持原 worker/队列行为。
- API：配置新增 `blocking_enabled`、运行态新增同步门禁状态与最近失败信息；模型请求新增稳定错误码 `prompt_guard_blocked`、`prompt_guard_unavailable`、`prompt_guard_invalid_response`。
- 安全与隐私：同步路径不持久化原始提示词；Guard 端点访问必须限制协议、重定向和响应体，并对远程端点执行安全校验。
- 风险：同步扫描会增加请求延迟并把 Guard 可用性引入主链路；误报会直接阻止用户请求，协议覆盖不完整会形成旁路。通过分组灰度、严格测试、结构化观测、fail-closed 错误区分和一键关闭同步开关控制风险。
- 回滚：将“同步阻止”关闭后，所有请求恢复现有异步只审计语义；新增配置字段由旧版本忽略，不要求数据回迁。
