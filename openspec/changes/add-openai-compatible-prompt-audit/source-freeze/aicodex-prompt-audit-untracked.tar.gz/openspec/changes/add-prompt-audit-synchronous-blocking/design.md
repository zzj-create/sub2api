## Context

当前提示词审计在 `HTTPEnqueueMiddleware` 或 relay 读取请求体后复制正文，并通过 goroutine 创建异步任务；主请求不会等待 worker，worker 后续才调用 OpenAI 兼容 Qwen3Guard、归一化 `Allow/Warn/Block` 并保存事件。因此现有 `Block` 是审计标签而不是执行门禁。

本变更由管理员在提示词审计页底部保存栏显式选择执行模式。红框区域新增“同步阻止”开关，与“启用审计”“保留通过事件”并列；关闭时完全保持现有异步链路，开启时把 Guard 判定提升为请求进入渠道选择、预扣费和上游发送之前的同步门禁。

该能力横跨控制面配置、`6068` Gin 入口、`9068` gateway adapter、OpenAI/Claude/Gemini 协议、Responses WebSocket、计费边界、审计事件和 `webui/`，必须维持以下硬约束：

- 控制面负责保存、校验和发布版本化的期望状态；数据面只读取原子运行时快照并执行门禁。
- `6068` 与 `9068` 必须复用同一判定契约，禁止各自维护不同的阻止规则。
- 被阻止请求不得选择渠道、预扣费、触发上游请求或进入上游重试。
- 同步路径不得把完整提示词写入数据库、日志、错误响应或前端状态。
- 现有异步审计是兼容基线；新增字段缺省时必须关闭同步阻止。

主要 owner：

- 控制面与审计服务 owner：配置 API、Guard adapter、结果记录和管理台运行态。
- 网关内核 owner：同步判定契约、数据面运行时快照和副作用边界。
- 协议/数据面 owner：`6068`、`9068`、SSE 与 Responses WebSocket 接线及协议错误映射。
- 控制台 owner：底部开关、风险确认、有效状态和回滚交互。

## Goals / Non-Goals

**Goals:**

- 通过 `blocking_enabled` 在同一套配置中稳定表达“异步只审计”和“同步审计并阻止”两种模式。
- 同步模式复用现有提示词提取、最新输入优先、Unicode 分片、Qwen3Guard 分类和归一化能力。
- 在所有已支持文本入口中，把同步判定放在计费与上游副作用之前。
- 对 `Block`、Guard 不可用和非法响应提供稳定、协议兼容且可观测的拒绝语义。
- 将同步判定结果复用到现有脱敏审计事件，避免对同一请求重复调用 Guard。
- 支持按现有审计分组范围灰度，并允许通过关闭开关快速回到异步模式。

**Non-Goals:**

- 不审核模型输出，不在流式响应生成后做中途截断。
- 不实现 `Redact` 请求体改写或风险内容替换。
- 不新增通用大模型 Guard prompt；继续使用 Qwen3Guard 的专用输入与输出契约。
- 不新增人工审批、用户申诉或逐请求临时放行流程。
- 不实现多 Guard 仲裁、投票或基于未校准数值 score 的置信度阈值。
- 不修改 HTTP 安全审计页面、Caddy 路由形态或外部部署端口。
- 不新增数据库表；若实现阶段发现现有 Ent 事件模型无法承载同步结果，必须先回到本设计补充数据模型决策，不能临时引入 GORM 表。

## Decisions

### 1. 使用两个布尔字段表达三态，不把“阻止”混入现有调度策略

配置增加 `blocking_enabled`，旧配置缺失时归一为 `false`。有效状态如下：

| `enabled` | `blocking_enabled` | 有效行为 |
| --- | --- | --- |
| `false` | 任意值 | 审计关闭；运行时强制视为 `blocking_enabled=false` |
| `true` | `false` | 当前异步只审计 |
| `true` | `true` | 同步判定并阻止，判定结果复用到审计事件 |

前端在关闭“启用审计”时自动关闭并禁用“同步阻止”；后端仍必须拒绝 `enabled=false && blocking_enabled=true` 的保存请求，返回稳定错误码 `prompt_guard_requires_audit_enabled`，避免仅依赖前端状态。

开启“同步阻止”时展示二次确认，明确说明“请求会等待 Guard；命中 Block 或 Guard 不可用时不会访问上游”。开关修改只进入页面草稿，仍由“保存配置”统一提交。

备选方案是把模式建模为 `mode=off|observe|enforce`。本次选择布尔字段是为了兼容现有 `enabled` API 和截图中的交互，但运行时仍必须集中计算三态，禁止散落布尔判断。

### 2. 新增纯同步门禁契约，异步审计继续作为独立记录能力

在网关边界内核定义不依赖 Gin、数据库和具体协议 controller 的门禁契约，核心输入至少包含：

- `request_id`、`user_id`、`token_id`、`group`
- `protocol`、`endpoint`、`model`
- 已提取的完整文本快照、prompt hash、消息数量
- `config_version`、启用的检测类别和 Guard 节点快照

核心输出至少包含：

- `decision=allow|flag|block|unavailable`
- `action=Allow|Warn|Block`
- 分类、scanner、policy、耗时、分片统计
- 稳定错误码和是否允许进入下一个副作用阶段

`gatewaycore` 持有契约和副作用不变量；`service/promptaudit` 提供 Qwen3Guard scanner 与脱敏结果记录 adapter；`gatewayadapter/transport` 和 `6068` router/controller 只做协议适配及依赖装配。纯数据面包不得反向依赖控制面 controller。

异步模式继续执行现有 `enqueue -> worker -> scan -> event`。同步模式执行 `extract -> evaluate -> decide`，随后把已经得到的归一化结果交给轻量结果记录路径；记录路径不得再次读取原始正文或重新调用 Guard。记录失败输出结构化告警，但不得把已经确定的 Allow 改成失败，也不得撤销已经确定的 Block。

### 3. 同步门禁固定放在鉴权/滥用保护之后、渠道与计费之前

HTTP 推荐顺序：

```text
TokenAuth
→ UserConcurrencyLimit
→ ModelRequestRateLimit
→ PromptGuardEnforce
→ Distribute
→ PriorityAdmission
→ Billing PreConsume
→ Upstream Relay
```

这样 Guard 调用仍受用户并发与请求速率保护，但被阻止请求不会占用渠道、优先级 admission、计费或上游资源。`6068` 与 `9068` 必须调用同一 evaluator；结构测试需要验证所有受支持 POST 路由都经过门禁。

SSE 必须在同步判定完成前不写响应头和首字节。普通 HTTP `Block` 返回 403；Guard 不可用或响应非法返回 503。错误体使用各协议既有 envelope，但共享稳定 `error_code`。

### 4. Responses WebSocket 使用帧级门禁，且早于每轮预扣与转发

WebSocket GET 握手没有提示词，不能只靠 HTTP middleware。Responses WS 必须：

1. 读取并解析首个 `response.create` 帧。
2. 在首轮预扣费和拨号上游之前执行同步门禁。
3. 对连接存续期间每个后续 `response.create` 重复执行同一门禁。
4. 只有 Allow/Flag 才可创建本轮 billing pending turn 并向上游发送帧。

命中 Block 时，该帧不得发送上游、不得创建本轮预扣；服务端使用 close code `4403` 和稳定 reason `prompt_guard_blocked` 结束连接。Guard 不可用或响应非法时使用 close code `1013`，reason 分别为 `prompt_guard_unavailable` 或 `prompt_guard_invalid_response`。日志必须区分 `stage=first_turn|subsequent_turn`。

### 5. Qwen3Guard 只负责分类，服务端策略负责最终阻止

继续按现有专用模型契约把每个文本分片作为 `role=user` 发送，保持 `temperature=0` 和确定性参数；不添加可能改变专用模型行为的通用 system prompt。

解析器必须严格验证：

- 响应正文有上限。
- 只能出现一个 `Safety` 和一个 `Categories` 字段，禁止重复或额外非空说明。
- `Safety` 必须是 `Safe|Controversial|Unsafe`。
- 已知分类必须归一到 Qwen3Guard 官方目录；未知分类单独标记，不得静默当作 clean。

模型 adapter 返回分类事实，不直接拥有租户策略。服务端按以下第一版确定性规则映射：

- `Safe` → `Allow`。
- `Controversial` 默认映射为 `Warn`；但命中至少一个已启用的高风险类别 `Jailbreak`、`PII` 或 `Suicide & Self-Harm` 时，保持现有策略映射为 `Block`，防止开启同步模式后弱化既有审计判定。
- `Unsafe` 且命中至少一个已启用类别 → `Block`。
- `Unsafe` 但没有可解析类别 → `Block`，类别记为 `unknown_unsafe`。
- `Unsafe` 仅命中管理员明确未启用的已知类别 → 不触发同步 Block，但保留审计事实，避免“关闭类别”仍产生硬阻止。

高风险 `Controversial` 的 Block 同样受启用类别约束：只有命中的高风险类别已启用时才阻止；若这些类别均被管理员明确关闭，则保留 Warn 审计事实并允许转发。

现有 scanner score 是标签映射值，不是真实置信度，本变更不得把它作为阻止阈值。未来若引入置信度，必须单独建立标注集、校准和规格。

### 6. 同步分片必须完整覆盖，允许风险早停但禁止部分放行

复用现有“最新用户输入作为独立首片、其余历史按 Unicode 字符完整分片”的行为。同步模式遇到任一分片 Block 可以立即早停并阻止；只有全部非空分片都成功得到非 Block 结果后才可放行。

同步总预算使用优先级列表中首个启用 Guard 节点的 `timeout_ms` 作为整次 evaluation 上限，所有分片和故障切换共享同一个 deadline；单个调用只能使用剩余时间。异步 worker 仍保持现有任务超时语义。超出总预算、任一必要分片失败或没有节点能产生合法结果时返回 unavailable，禁止保存部分扫描组成的 Allow。

第一版继续顺序扫描并优先最新输入，不并行放大 Guard 压力。若真实流量证明长提示词延迟不可接受，再以独立变更引入有界并行和容量模型。

### 7. 同步模式采用固定 fail-closed 与明确的优先级故障切换

同步模式不增加可配置 fail-open。所有启用节点按配置顺序尝试：

- 合法分类结果立即结束节点故障切换并进入策略映射。
- 连接失败、429、5xx 或超时只在总 deadline 尚有剩余时尝试下一个节点。
- 401/403、非法响应或所有节点失败最终返回 503，不得异步降级后放行。

前后端调度策略统一为 `priority`，语义是有序故障切换。控制台不再提交 `round_robin`；后端对新保存请求中的未知策略返回校验错误，不再静默归一。已有历史值在加载时迁移为 `priority` 并输出一次脱敏迁移日志。

选择固定 fail-closed 是因为开启开关即代表管理员要求硬阻止。若将来需要“同步观察但 Guard 故障放行”，应新增独立模式而不是弱化本开关。

### 8. 配置作为版本化控制面快照发布给数据面

现有配置 JSON 增加 `blocking_enabled` 和单调递增的 `config_version`；保存时记录 `updated_at`、操作者和变更原因摘要。旧配置缺失版本时从兼容基线版本开始。

控制面保存成功后清除本实例缓存，并通过现有 Redis 能力发布配置失效信号；各实例原子替换只读运行时快照。Redis 不可用时保留现有有界 TTL 刷新作为降级，但必须记录 `prompt_guard.config_reload_degraded`。数据面请求只读快照，不在每次请求热路径查询数据库。

运行态返回配置期望版本、当前实例生效版本、`blocking_enabled`、最近加载时间和最近加载错误。若某实例最后已知配置要求同步阻止但无法获得有效快照，该实例继续使用最后有效版本；冷启动且无法加载严格配置时，对适用请求 fail-closed。

### 9. Guard 端点属于受控高敏出站边界

同步模式会把完整待分类文本发送给管理员配置的 Guard，因此必须：

- 公网 Guard 端点只允许 HTTPS；HTTP 只允许显式本机或受控私网部署。
- 禁止访问 link-local、云元数据地址和未授权 scheme。
- 默认禁止重定向；如保留重定向，必须对每一跳重新执行同等校验。
- 使用独立 HTTP client、连接池、超时、响应体上限和全局/每节点并发 bulkhead。
- Authorization、API Key、完整 URL query 和提示词正文不得进入日志或错误响应。

探测成功仅表示节点可连接，不能替代每次请求的真实分类结果。节点熔断或 bulkhead 饱和在同步模式下归类为 unavailable，并快速返回 503，禁止无限排队。

### 10. 协议错误、日志与指标使用稳定契约

稳定错误码：

- `prompt_guard_blocked`：分类命中 Block，HTTP 403 / WS 4403。
- `prompt_guard_unavailable`：超时、节点不可用、熔断或容量不足，HTTP 503 / WS 1013。
- `prompt_guard_invalid_response`：Guard 输出无法严格解析，HTTP 503 / WS 1013。
- `prompt_guard_requires_audit_enabled`：配置组合非法，控制面保存返回 400。

模型 API 错误响应只暴露通用中文消息、稳定错误码和 `request_id`，不向调用方返回具体命中正文或内部 Guard 地址。

结构化事件至少包括：

- `prompt_guard.config_updated`
- `prompt_guard.config_loaded`
- `prompt_guard.config_reload_degraded`
- `prompt_guard.evaluation_started`
- `prompt_guard.allowed`
- `prompt_guard.blocked`
- `prompt_guard.failed`
- `prompt_guard.result_record_failed`

最小字段：`request_id`、`user_id`、`token_id`、`group`、`protocol`、`endpoint`、`model`、`config_version`、`policy_id`、`policy_version`、`guard_endpoint_id`、`decision`、`action`、`chunk_total`、`latency_ms`、`status`、`error_code`、`stage`。阻止日志还必须包含 `upstream_dispatched=false`、`billing_preconsumed=false`，但禁止输出正文、API Key、Token、Authorization 或完整 Guard URL。

指标至少覆盖 evaluation 总数、Allow/Flag/Block/Unavailable 分布、Guard 延迟、非法响应、超时、节点故障切换和结果记录失败。

## Risks / Trade-offs

- [同步 Guard 增加所有适用请求的首字节延迟] → 最新输入优先、Block 早停、共享总 deadline、节点连接池和按分组灰度；上线门禁前必须测量 P50/P95/P99。
- [Guard 故障会在 fail-closed 下影响模型可用性] → 配置多个优先级节点、bulkhead、熔断、运行态告警和一键关闭同步开关；503 与真实策略 Block 明确分离。
- [Qwen3Guard 误报会直接拒绝合法请求] → 先在异步模式收集候选 Block、使用管理员选定分组灰度、建立良性/恶意回归语料，并监控 Block 比率突变。
- [长提示词顺序分片可能超过总预算] → 全部完成前禁止放行；通过 input limit、总 deadline 和日志识别容量瓶颈，后续再决定是否引入有界并行。
- [协议入口漏接会形成旁路] → 建立 `6068/9068 × OpenAI/Responses/Claude/Gemini/任务 × HTTP/SSE/WS` 路由矩阵测试，并以“上游调用次数与预扣次数均为 0”作为 Block 断言。
- [多实例配置短暂不一致] → 版本化快照、Redis 失效通知、实例生效版本运行态和最后有效版本；失效通知失败必须可观测。
- [同步结果记录失败导致控制台缺事件] → 判定日志作为最低审计证据，结果记录独立重试且不包含正文；记录失败不得改变已执行的 Allow/Block。
- [端点安全加固影响现有 HTTP Guard] → 兼容本机与显式受控私网 HTTP，公网强制 HTTPS；上线前探测全部现有节点并提供明确迁移错误。

## Migration Plan

1. 先部署向后兼容的配置与运行态字段，旧配置自动得到 `blocking_enabled=false`，所有请求仍走异步模式。
2. 部署共享 evaluator、HTTP/WS 门禁接线、严格解析、协议错误和结构化日志，但保持开关关闭。
3. 在异步模式用现有事件建立候选 Block、误报、Guard 延迟和节点稳定性基线。
4. 在控制台加入“同步阻止”开关与确认提示，先仅对选定测试分组开启。
5. 依次完成本地单测、协议集成测试和 `deploy/` 栈级验证，确认 Block 请求的上游调用和预扣均为 0。
6. 按分组逐步扩大范围，持续观察 Block 率、Unavailable 率和 P95/P99 延迟。

回滚时只需关闭“同步阻止”并保存，运行时恢复异步投递；保留新增字段、日志和历史事件，无需数据库回迁。若控制面不可用，可通过受控配置回滚把 `blocking_enabled` 置为 `false`，不得通过删除审计表或关闭安全校验实现回滚。

## Open Questions

- 本变更没有阻塞提案审核的问题。实现前由审核人确认两项产品决策：同步模式固定 fail-closed；Responses WebSocket 命中 Block 后关闭连接而不是仅拒绝单轮并保持连接。
