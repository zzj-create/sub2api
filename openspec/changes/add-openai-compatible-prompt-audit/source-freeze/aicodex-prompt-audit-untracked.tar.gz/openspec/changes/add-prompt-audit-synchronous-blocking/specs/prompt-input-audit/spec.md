## MODIFIED Requirements

### Requirement: 提示词审计必须提供独立控制台页面

系统 SHALL 提供独立的“提示词审计”控制台页面，用于管理 OpenAI 兼容 Guard 审计池、异步审计开关、同步阻止开关、通过事件保留、适用分组、运行态状态、审计事件列表和事件详情，且不得修改现有 HTTP 审计页面的行为。

#### Scenario: 管理员打开提示词审计页面
- **WHEN** 管理员进入提示词审计页面
- **THEN** 页面 MUST 展示 Guard 审计池配置状态、提示词审计启用状态、同步阻止有效状态、主进程 worker 运行态和最近错误信息
- **THEN** 页面 MUST NOT 复用或改变现有 HTTP 审计页面的规则列表、事件列表和运行态接口

#### Scenario: 保存 OpenAI 兼容 Guard 配置
- **WHEN** 管理员输入 Guard Base URL、API Key、Model、超时时间并保存
- **THEN** 系统 MUST 持久化配置并返回保存结果
- **THEN** 系统 MUST NOT 在响应、日志或页面状态中回显 API Key 明文

#### Scenario: 启用用户输入提示词审计
- **WHEN** 管理员在提示词审计页面开启“启用审计”且至少一个 Guard 审计池配置可用
- **THEN** 系统 MUST 开始执行当前选择的提示词审计模式
- **THEN** 系统 MUST 在运行态状态中展示审计开关已启用

#### Scenario: 底部保存栏展示同步阻止开关
- **WHEN** 管理员查看提示词审计配置页底部保存栏
- **THEN** 页面 MUST 在“启用审计”和“保留通过事件”旁展示“同步阻止”开关
- **AND** 页面 MUST 明确说明关闭时为异步只审计，开启时请求会在转发前等待 Guard 判定

#### Scenario: 管理员开启同步阻止
- **WHEN** “启用审计”已开启且管理员打开“同步阻止”
- **THEN** 页面 MUST 展示风险确认，说明命中 Block 或 Guard 不可用时请求不会访问上游
- **AND** 确认后的修改 MUST 只进入页面配置草稿
- **AND** 系统 MUST 在管理员点击“保存配置”成功后才使同步阻止生效

#### Scenario: 管理员关闭审计
- **WHEN** 管理员关闭“启用审计”
- **THEN** 页面 MUST 同时关闭并禁用“同步阻止”
- **AND** 保存后的运行时有效 `blocking_enabled` MUST 为 `false`

#### Scenario: 配置存在未保存修改
- **WHEN** 管理员修改“同步阻止”但尚未保存
- **THEN** 页面 MUST 把该修改纳入既有脏状态和“丢弃变更”能力
- **AND** 刷新运行态 MUST NOT 把未保存草稿误显示为已生效配置

### Requirement: 主网关必须异步投递用户输入提示词审计任务

系统 SHALL 在 `blocking_enabled=false` 的异步只审计模式中，从主模型请求链路提取用户输入提示词快照并异步投递审计任务，且该投递不得阻塞或改变模型请求转发结果。`blocking_enabled=true` 时，系统 SHALL 改由 `prompt-input-guard` 同步判定并复用结果到审计事件，MUST NOT 为同一请求再次投递需要重复调用 Guard 的原始扫描任务。

#### Scenario: OpenAI Chat Completions 用户消息被异步投递
- **WHEN** `blocking_enabled=false` 且用户调用 `/v1/chat/completions`，请求体包含 `role=user` 的消息
- **THEN** 系统 MUST 为用户消息生成提示词审计任务
- **THEN** 审计任务 MUST 包含 `request_id`、`user_id`、`token_id`、`endpoint`、`model`、提示词 hash 和脱敏预览

#### Scenario: OpenAI Responses 用户输入被异步投递
- **WHEN** `blocking_enabled=false` 且用户调用 `/v1/responses`，请求体包含用户输入文本
- **THEN** 系统 MUST 为用户输入文本生成提示词审计任务
- **THEN** 审计任务 MUST 标记来源 endpoint 为 Responses 相关类型

#### Scenario: Claude Messages 用户消息被异步投递
- **WHEN** `blocking_enabled=false` 且用户调用 Claude Messages 兼容入口，请求体包含 `role=user` 的消息
- **THEN** 系统 MUST 为用户消息生成提示词审计任务
- **THEN** 审计任务 MUST 保留协议类型，便于后台筛选和排查

#### Scenario: 异步审计队列不可用
- **WHEN** `blocking_enabled=false` 且提示词审计队列已满或暂不可用
- **THEN** 主模型请求 MUST 继续按原有链路转发
- **THEN** 系统 MUST 输出 `event = "prompt_audit.enqueue_dropped"` 的结构化日志

#### Scenario: 同步模式不重复投递原始扫描任务
- **WHEN** `blocking_enabled=true` 且同步门禁已经完成 Guard 判定
- **THEN** 系统 MUST NOT 为同一请求再次投递需要原始提示词的扫描任务
- **AND** 系统 MUST 使用已经得到的归一化结果执行脱敏事件记录

#### Scenario: 同步模式结果记录队列不可用
- **WHEN** `blocking_enabled=true` 且同步判定已完成，但脱敏结果记录队列暂不可用
- **THEN** 系统 MUST 保持已经确定的 Allow 或 Block
- **AND** 系统 MUST 输出 `prompt_guard.result_record_failed`

### Requirement: 提示词审计处理器必须由主 AICodex 进程内 worker 执行

系统 SHALL 由主 `aicodex` 进程内的提示词审计 worker 消费异步审计任务，调用管理员配置的 OpenAI 兼容 Guard，并将 scanner 结果归一化为 AICodex 审计事件。同步阻止模式 SHALL 在请求关键路径使用共享 evaluator，不得把硬阻止交给异步 worker 决定。系统 MUST NOT 要求部署仓库内独立 `prompt-auditd` 进程才能消费任务或执行同步门禁。

#### Scenario: 主进程启动提示词审计 worker
- **WHEN** 主 `aicodex` 进程启动且提示词审计配置、日志库和 Redis 临时载荷存储可用
- **THEN** 系统 MUST 在主进程内启动提示词审计 worker
- **THEN** 系统 MUST 输出 `event = "prompt_audit.started"` 的结构化日志
- **THEN** 日志 MUST 包含队列容量、worker 数、外部 Guard 配置状态、审计开关状态和同步阻止状态

#### Scenario: worker 启动失败时异步模式降级运行
- **WHEN** 主 `aicodex` 进程启动但提示词审计 worker 因日志库、Redis 或配置异常无法启动，且 `blocking_enabled=false`
- **THEN** 主 API 进程 MUST 继续启动并服务非审计请求
- **THEN** 系统 MUST 输出稳定事件名和错误码的结构化日志
- **THEN** 运行态 MUST 暴露 worker 未运行或降级错误，不得伪装为健康

#### Scenario: 同步模式不依赖异步 worker 作出判定
- **WHEN** `blocking_enabled=true` 且异步 worker 未运行
- **THEN** 同步 evaluator MUST 仍按当前有效配置执行判定
- **AND** worker 状态 MUST NOT 被误用为请求已通过门禁的依据
- **AND** 同步 evaluator 自身不可用时 MUST 按 fail-closed 拒绝适用请求

#### Scenario: worker 调用外部 Guard
- **WHEN** 主进程内 worker 领取到异步提示词审计任务
- **THEN** worker MUST 从短 TTL 临时载荷中读取完整扫描文本
- **THEN** worker MUST 调用管理员配置的 OpenAI 兼容 Guard
- **THEN** worker MUST 等待外部 Guard 返回扫描结果后再写入归一化审计事件或更新任务状态

#### Scenario: Guard 返回风险 scanner 命中
- **WHEN** 外部 Guard 返回 Qwen3Guard 风险分类或等价 scanner 命中
- **THEN** 系统 MUST 写入提示词审计事件
- **THEN** 事件 MUST 包含 `decision`、`risk_level`、`categories`、`matched_scanners`、`scanner_scores`、`scanner_backend` 和 `latency_ms`
- **THEN** 系统 MUST 输出 `event = "prompt_audit.finding_recorded"` 的结构化日志

#### Scenario: Guard 返回无风险
- **WHEN** 外部 Guard 返回输入安全且无风险 scanner 命中
- **THEN** 系统 MUST 将异步任务标记为已处理
- **THEN** 系统 MAY 只记录聚合统计而不持久化低价值通过事件

#### Scenario: 外部 Guard 调用失败
- **WHEN** 异步 worker 调用 Guard 遇到认证失败、超时、非 2xx 状态、连接失败或响应结构异常
- **THEN** worker MUST 标记任务失败或进入可重试状态
- **THEN** worker MUST 输出 `event = "prompt_audit.process_failed"` 的结构化日志
- **THEN** `blocking_enabled=false` 时主模型请求历史结果 MUST NOT 因异步审计失败而改变

#### Scenario: 回收滞留 processing 任务
- **WHEN** 异步提示词审计任务处于 `processing` 且超过 worker 可接受处理时长
- **THEN** 系统 MUST 将该任务回收到可重试或失败状态
- **THEN** 系统 MUST 记录稳定错误码用于解释积压原因
- **THEN** 后续 worker MUST 能继续领取可重试任务，避免单条任务永久积压

### Requirement: 提示词审计运行态必须反映主进程内 worker

系统 SHALL 提供提示词审计运行态接口和结构化日志，使管理员和 AI 智能体能够判断异步 worker、同步门禁、配置版本、队列、Guard 节点和最近失败的真实状态。

#### Scenario: 查询提示词审计运行态
- **WHEN** 管理员打开提示词审计页面或调用运行态接口
- **THEN** 系统 MUST 返回审计启用状态、`blocking_enabled`、有效执行模式、主进程 worker 运行状态、队列长度、处理总数、失败总数、最近错误码、最近错误信息和 Guard 连通性
- **AND** 系统 MUST 返回控制面期望 `config_version`、当前实例生效版本和最近配置加载时间
- **THEN** Guard 连通性 MUST 来自后端真实探测或执行状态，不得由前端本地模拟

#### Scenario: 外部 Guard 未探测或不可达
- **WHEN** 外部 Guard 尚未被后端探测或后端无法访问该 Guard
- **THEN** 提示词审计页面 MUST 展示 `unknown`、`error` 或 `degraded` 等真实运行态
- **THEN** 页面 MUST NOT 仅因 Base URL 已填写就展示健康状态

#### Scenario: 同步阻止已启用但配置版本未加载
- **WHEN** 控制面期望配置开启同步阻止，但当前实例尚未加载对应版本
- **THEN** 运行态 MUST 显示期望版本与生效版本不一致
- **AND** 系统 MUST 暴露稳定加载错误或降级原因
- **AND** 页面 MUST NOT 把该实例展示为同步门禁完全健康

#### Scenario: 停用提示词审计
- **WHEN** 管理员关闭提示词审计开关
- **THEN** 主网关 MUST 停止投递新的异步提示词审计任务
- **THEN** 同步门禁 MUST 停止执行新请求判定
- **THEN** 主进程内 worker MUST 不再调用外部 Guard 处理新任务
- **THEN** 现有 HTTP 审计能力 MUST 保持原行为

#### Scenario: 关闭同步阻止但保留审计
- **WHEN** 管理员保持 `enabled=true` 并关闭 `blocking_enabled`
- **THEN** 运行态 MUST 展示异步只审计模式
- **AND** 新请求 MUST 恢复异步投递，不再等待同步 Guard
