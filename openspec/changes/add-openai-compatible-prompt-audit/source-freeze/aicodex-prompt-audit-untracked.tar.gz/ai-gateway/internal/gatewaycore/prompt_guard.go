package gatewaycore

import (
	"context"
	"time"
)

const (
	PromptGuardDecisionAllow       = "allow"
	PromptGuardDecisionFlag        = "flag"
	PromptGuardDecisionBlock       = "block"
	PromptGuardDecisionUnavailable = "unavailable"

	PromptGuardErrorBlocked         = "prompt_guard_blocked"
	PromptGuardErrorUnavailable     = "prompt_guard_unavailable"
	PromptGuardErrorInvalidResponse = "prompt_guard_invalid_response"
)

// PromptGuardInput 是数据面同步提示词门禁的协议无关输入。
// Text 只允许在请求内存中短暂存在，禁止写入日志、错误响应或持久化事件。
type PromptGuardInput struct {
	RequestID     string
	UserID        int
	TokenID       int
	Group         string
	Protocol      string
	Endpoint      string
	Model         string
	Text          string
	PromptHash    string
	MessageCount  int
	ConfigVersion int64
	Stage         string
}

// PromptGuardResult 是 6068、9068 和 Responses WebSocket 共享的判定契约。
type PromptGuardResult struct {
	Decision           string
	Action             string
	Categories         []string
	ObservedCategories []string
	MatchedScanners    []string
	ScannerScores      map[string]float64
	ScannerBackend     string
	ScannerVersion     string
	PolicyID           string
	PolicyVersion      int
	GuardEndpointID    string
	ChunkTotal         int
	Latency            time.Duration
	ErrorCode          string
	AllowNextStage     bool
}

// PromptGuardEvaluator 不依赖 Gin、控制器、数据库和具体协议。
type PromptGuardEvaluator interface {
	Evaluate(context.Context, PromptGuardInput) PromptGuardResult
}
