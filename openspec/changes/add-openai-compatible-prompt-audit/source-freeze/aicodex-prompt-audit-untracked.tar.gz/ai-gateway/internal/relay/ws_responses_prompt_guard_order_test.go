package relay

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	basecommon "github.com/mt21625457/aicodex/internal/common"
	"github.com/mt21625457/aicodex/internal/constant"
	"github.com/mt21625457/aicodex/internal/dto"
	"github.com/mt21625457/aicodex/internal/gatewaycore"
	relaychannel "github.com/mt21625457/aicodex/internal/relay/channel"
	relaycommon "github.com/mt21625457/aicodex/internal/relay/common"
	openaiwsv2 "github.com/mt21625457/aicodex/internal/relay/openai_ws_v2"
	"github.com/mt21625457/aicodex/internal/service/promptaudit"
	"github.com/mt21625457/aicodex/internal/types"

	coderws "github.com/coder/websocket"
)

type responsesWSPromptGuardSequenceEvaluator struct {
	results []gatewaycore.PromptGuardResult
	calls   atomic.Int32
}

func (e *responsesWSPromptGuardSequenceEvaluator) Evaluate(context.Context, gatewaycore.PromptGuardInput) gatewaycore.PromptGuardResult {
	index := int(e.calls.Add(1)) - 1
	if index >= 0 && index < len(e.results) {
		return e.results[index]
	}
	return gatewaycore.PromptGuardResult{
		Decision:       gatewaycore.PromptGuardDecisionUnavailable,
		ErrorCode:      gatewaycore.PromptGuardErrorUnavailable,
		AllowNextStage: false,
	}
}

func TestResponsesWSPromptGuardPrecedesChannelBillingAndDispatch(t *testing.T) {
	_, current, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("无法定位测试文件")
	}
	source, err := os.ReadFile(filepath.Join(filepath.Dir(current), "ws_responses.go"))
	if err != nil {
		t.Fatalf("读取 ws_responses.go: %v", err)
	}
	text := string(source)
	firstGuard := strings.Index(text, "firstGuardCheck := promptaudit.EvaluatePromptGuardBody")
	prepare := strings.Index(text, "prepared, prepErr := dataplaneopenai.PrepareWSForwarding")
	preconsume := strings.Index(text, "if apiErr := enqueueResponsesWSPendingTurn")
	firstAsyncEnqueue := strings.Index(text, "promptaudit.MaybeEnqueueTurnFromGateway(c, types.RelayFormatOpenAIResponsesWS, firstMessage)")
	dispatch := strings.Index(text, "respAny, doReqErr := responsesWSDoRequest")
	if firstGuard < 0 || prepare < 0 || preconsume < 0 || firstAsyncEnqueue < 0 || dispatch < 0 || !(firstGuard < prepare && prepare < preconsume && preconsume < firstAsyncEnqueue && firstAsyncEnqueue < dispatch) {
		t.Fatalf("首轮门禁必须早于渠道选择和预扣，异步入队必须保留在预扣后: guard=%d prepare=%d preconsume=%d enqueue=%d dispatch=%d", firstGuard, prepare, preconsume, firstAsyncEnqueue, dispatch)
	}

	callback := strings.Index(text, "BeforeClientFrame: func")
	if callback < 0 {
		t.Fatal("未找到 Responses WS 后续帧回调")
	}
	remaining := text[callback:]
	nextGuard := strings.Index(remaining, "guardCheck := promptaudit.EvaluatePromptGuardBody")
	nextPreconsume := strings.Index(remaining, "if apiErr := enqueueResponsesWSPendingTurn")
	nextAsyncEnqueue := strings.Index(remaining, "promptaudit.MaybeEnqueueTurnFromGateway(c, types.RelayFormatOpenAIResponsesWS, payload)")
	if nextGuard < 0 || nextPreconsume < 0 || nextAsyncEnqueue < 0 || !(nextGuard < nextPreconsume && nextPreconsume < nextAsyncEnqueue) {
		t.Fatalf("后续轮次门禁必须早于本轮预扣，异步入队必须保留在预扣后: callback=%d guard=%d preconsume=%d enqueue=%d", callback, nextGuard, nextPreconsume, nextAsyncEnqueue)
	}
}

func TestResponsesWSPromptGuardCloseCodeContract(t *testing.T) {
	tests := []struct {
		name       string
		check      promptaudit.PromptGuardCheck
		wantCode   int
		wantReason string
	}{
		{name: "block", check: promptaudit.PromptGuardCheck{Allowed: false, StatusCode: http.StatusForbidden, ErrorCode: "prompt_guard_blocked"}, wantCode: 4403, wantReason: "prompt_guard_blocked"},
		{name: "unavailable", check: promptaudit.PromptGuardCheck{Allowed: false, StatusCode: http.StatusServiceUnavailable, ErrorCode: "prompt_guard_unavailable"}, wantCode: 1013, wantReason: "prompt_guard_unavailable"},
		{name: "invalid", check: promptaudit.PromptGuardCheck{Allowed: false, StatusCode: http.StatusServiceUnavailable, ErrorCode: "prompt_guard_invalid_response"}, wantCode: 1013, wantReason: "prompt_guard_invalid_response"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			apiErr := promptGuardAICodexError(tt.check)
			code, reason := mapResponsesWSErrorToCloseCode(apiErr, "client_before_frame", apiErr.StatusCode)
			if int(code) != tt.wantCode || reason != tt.wantReason {
				t.Fatalf("unexpected close mapping: code=%d reason=%q", code, reason)
			}
		})
	}
}

func TestResponsesWSPromptGuardFirstTurnRejectsBeforeAllSideEffects(t *testing.T) {
	gin.SetMode(gin.TestMode)
	installResponsesWSPromptGuardConfig(t)

	oldSelectChannel := responsesWSSelectChannel
	oldPreConsume := responsesWSPreConsumeBilling
	oldDoRequest := responsesWSDoRequest
	t.Cleanup(func() {
		responsesWSSelectChannel = oldSelectChannel
		responsesWSPreConsumeBilling = oldPreConsume
		responsesWSDoRequest = oldDoRequest
	})
	var selectCalls atomic.Int32
	var preconsumeCalls atomic.Int32
	var dispatchCalls atomic.Int32
	responsesWSSelectChannel = func(*gin.Context, string) *types.AICodexError {
		selectCalls.Add(1)
		return nil
	}
	responsesWSPreConsumeBilling = func(*gin.Context, int, *relaycommon.RelayInfo) *types.AICodexError {
		preconsumeCalls.Add(1)
		return nil
	}
	responsesWSDoRequest = func(*gin.Context, relaychannel.Adaptor, *relaycommon.RelayInfo) (any, error) {
		dispatchCalls.Add(1)
		return nil, nil
	}

	tests := []struct {
		name       string
		result     gatewaycore.PromptGuardResult
		wantStatus coderws.StatusCode
	}{
		{
			name:       "Block",
			result:     gatewaycore.PromptGuardResult{Decision: gatewaycore.PromptGuardDecisionBlock, Action: "Block", ErrorCode: gatewaycore.PromptGuardErrorBlocked, AllowNextStage: false},
			wantStatus: coderws.StatusCode(4403),
		},
		{
			name:       "Unavailable",
			result:     gatewaycore.PromptGuardResult{Decision: gatewaycore.PromptGuardDecisionUnavailable, Action: "Unavailable", ErrorCode: gatewaycore.PromptGuardErrorUnavailable, AllowNextStage: false},
			wantStatus: coderws.StatusTryAgainLater,
		},
		{
			name:       "Invalid response",
			result:     gatewaycore.PromptGuardResult{Decision: gatewaycore.PromptGuardDecisionUnavailable, Action: "Unavailable", ErrorCode: gatewaycore.PromptGuardErrorInvalidResponse, AllowNextStage: false},
			wantStatus: coderws.StatusTryAgainLater,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			selectCalls.Store(0)
			preconsumeCalls.Store(0)
			dispatchCalls.Store(0)
			evaluator := &responsesWSPromptGuardSequenceEvaluator{results: []gatewaycore.PromptGuardResult{tt.result}}
			restoreEvaluator := promptaudit.SetPromptGuardEvaluatorForTesting(evaluator)
			defer restoreEvaluator()

			router := gin.New()
			router.GET("/v1/responses", func(c *gin.Context) { _ = WsResponsesHelper(c) })
			server := httptest.NewServer(router)
			defer server.Close()
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			conn, _, err := coderws.Dial(ctx, "ws"+strings.TrimPrefix(server.URL, "http")+"/v1/responses", nil)
			if err != nil {
				t.Fatalf("建立 Responses WebSocket 失败: %v", err)
			}
			defer conn.CloseNow()
			if err := conn.Write(ctx, coderws.MessageText, []byte(`{"type":"response.create","model":"gpt-5","input":"first-turn-secret"}`)); err != nil {
				t.Fatalf("发送首轮帧失败: %v", err)
			}
			_, _, readErr := conn.Read(ctx)
			if got := coderws.CloseStatus(readErr); got != tt.wantStatus {
				t.Fatalf("关闭码=%d，期望=%d，err=%v", got, tt.wantStatus, readErr)
			}
			if evaluator.calls.Load() != 1 || selectCalls.Load() != 0 || preconsumeCalls.Load() != 0 || dispatchCalls.Load() != 0 {
				t.Fatalf("首轮拒绝必须零副作用: guard=%d select=%d preconsume=%d dispatch=%d", evaluator.calls.Load(), selectCalls.Load(), preconsumeCalls.Load(), dispatchCalls.Load())
			}
		})
	}
}

func TestResponsesWSPromptGuardSubsequentTurnRejectsBeforeNewPreconsumeAndSend(t *testing.T) {
	gin.SetMode(gin.TestMode)
	installWsResponsesStaticModelPriceHook(t)
	installResponsesWSPromptGuardConfig(t)

	oldGetRuntimeSettings := responsesWSGetRuntimeSettings
	oldSelectChannel := responsesWSSelectChannel
	oldBuildRelayInfo := responsesWSBuildRelayInfo
	oldModelMapped := responsesWSModelMapped
	oldGetAdaptor := responsesWSGetAdaptor
	oldDoRequest := responsesWSDoRequest
	oldRunEntry := responsesWSRunEntry
	oldValidateTurnAccess := responsesWSValidateTurnAccess
	oldPreConsume := responsesWSPreConsumeBilling
	oldPostConsume := responsesWSPostTextConsumeQuota
	oldRecordAffinity := responsesWSRecordChannelAffinity
	t.Cleanup(func() {
		responsesWSGetRuntimeSettings = oldGetRuntimeSettings
		responsesWSSelectChannel = oldSelectChannel
		responsesWSBuildRelayInfo = oldBuildRelayInfo
		responsesWSModelMapped = oldModelMapped
		responsesWSGetAdaptor = oldGetAdaptor
		responsesWSDoRequest = oldDoRequest
		responsesWSRunEntry = oldRunEntry
		responsesWSValidateTurnAccess = oldValidateTurnAccess
		responsesWSPreConsumeBilling = oldPreConsume
		responsesWSPostTextConsumeQuota = oldPostConsume
		responsesWSRecordChannelAffinity = oldRecordAffinity
	})

	responsesWSGetRuntimeSettings = func() responsesWSRuntimeSettings {
		return responsesWSRuntimeSettings{FirstMessageTimeout: 5 * time.Second, ReadLimit: 1024 * 1024, RelayDrainTimeout: time.Second, RelayIdleTimeout: 5 * time.Second}
	}
	responsesWSSelectChannel = func(c *gin.Context, modelName string) *types.AICodexError {
		basecommon.SetContextKey(c, constant.ContextKeyOriginalModel, modelName)
		basecommon.SetContextKey(c, constant.ContextKeyRequestStartTime, time.Now())
		basecommon.SetContextKey(c, constant.ContextKeyUserId, 1)
		basecommon.SetContextKey(c, constant.ContextKeyUserName, "tester")
		basecommon.SetContextKey(c, constant.ContextKeyUserGroup, "default")
		basecommon.SetContextKey(c, constant.ContextKeyUsingGroup, "default")
		basecommon.SetContextKey(c, constant.ContextKeyChannelType, constant.ChannelTypeOpenAI)
		basecommon.SetContextKey(c, constant.ContextKeyChannelId, 1)
		basecommon.SetContextKey(c, constant.ContextKeyChannelBaseUrl, "ws://example.com")
		basecommon.SetContextKey(c, constant.ContextKeyChannelOtherSetting, dto.ChannelOtherSettings{AllowServiceTier: true})
		return nil
	}
	responsesWSBuildRelayInfo = func(c *gin.Context) (*relaycommon.RelayInfo, error) {
		return relaycommon.GenRelayInfo(c, types.RelayFormatOpenAIResponsesWS, nil, nil)
	}
	responsesWSModelMapped = func(*gin.Context, *relaycommon.RelayInfo, dto.Request) error { return nil }
	responsesWSGetAdaptor = func(int) relaychannel.Adaptor { return testResponsesWSAdaptor{} }
	var dispatchCalls atomic.Int32
	responsesWSDoRequest = func(*gin.Context, relaychannel.Adaptor, *relaycommon.RelayInfo) (any, error) {
		dispatchCalls.Add(1)
		return nopFrameConn{}, nil
	}
	responsesWSValidateTurnAccess = func(*gin.Context, *relaycommon.RelayInfo) *types.AICodexError { return nil }
	var preconsumeCalls atomic.Int32
	responsesWSPreConsumeBilling = func(*gin.Context, int, *relaycommon.RelayInfo) *types.AICodexError {
		preconsumeCalls.Add(1)
		return nil
	}
	responsesWSPostTextConsumeQuota = func(*gin.Context, *relaycommon.RelayInfo, *dto.Usage, ...string) {}
	responsesWSRecordChannelAffinity = func(*gin.Context, int) {}

	tests := []struct {
		name       string
		second     gatewaycore.PromptGuardResult
		wantStatus coderws.StatusCode
	}{
		{name: "Block", second: gatewaycore.PromptGuardResult{Decision: gatewaycore.PromptGuardDecisionBlock, Action: "Block", ErrorCode: gatewaycore.PromptGuardErrorBlocked, AllowNextStage: false}, wantStatus: coderws.StatusCode(4403)},
		{name: "Unavailable", second: gatewaycore.PromptGuardResult{Decision: gatewaycore.PromptGuardDecisionUnavailable, Action: "Unavailable", ErrorCode: gatewaycore.PromptGuardErrorUnavailable, AllowNextStage: false}, wantStatus: coderws.StatusTryAgainLater},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			preconsumeCalls.Store(0)
			dispatchCalls.Store(0)
			evaluator := &responsesWSPromptGuardSequenceEvaluator{results: []gatewaycore.PromptGuardResult{
				{Decision: gatewaycore.PromptGuardDecisionAllow, Action: "Allow", AllowNextStage: true},
				tt.second,
			}}
			restoreEvaluator := promptaudit.SetPromptGuardEvaluatorForTesting(evaluator)
			defer restoreEvaluator()
			responsesWSRunEntry = func(input openaiwsv2.EntryInput) (openaiwsv2.RelayResult, *openaiwsv2.RelayExit) {
				if input.Options.OnTurnComplete != nil {
					input.Options.OnTurnComplete(openaiwsv2.RelayTurnResult{RequestID: "resp_1", RequestModel: "gpt-5", Usage: openaiwsv2.Usage{InputTokens: 3, OutputTokens: 1}, TerminalEventType: "response.completed", Duration: time.Second})
				}
				if input.Options.BeforeClientFrame != nil {
					if err := input.Options.BeforeClientFrame(2, coderws.MessageText, []byte(`{"type":"response.create","model":"gpt-5","input":"second-turn-secret"}`)); err != nil {
						return openaiwsv2.RelayResult{RequestID: "resp_1", TerminalEventType: "response.completed"}, &openaiwsv2.RelayExit{Stage: "before_client_frame", Err: err}
					}
				}
				return openaiwsv2.RelayResult{RequestID: "resp_1", TerminalEventType: "response.completed"}, nil
			}

			router := gin.New()
			router.GET("/v1/responses", func(c *gin.Context) { _ = WsResponsesHelper(c) })
			server := httptest.NewServer(router)
			defer server.Close()
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			conn, _, err := coderws.Dial(ctx, "ws"+strings.TrimPrefix(server.URL, "http")+"/v1/responses", nil)
			if err != nil {
				t.Fatalf("建立 Responses WebSocket 失败: %v", err)
			}
			defer conn.CloseNow()
			if err := conn.Write(ctx, coderws.MessageText, []byte(`{"type":"response.create","model":"gpt-5","input":"first-turn-safe"}`)); err != nil {
				t.Fatalf("发送首轮帧失败: %v", err)
			}
			_, _, readErr := conn.Read(ctx)
			if got := coderws.CloseStatus(readErr); got != tt.wantStatus {
				t.Fatalf("后续轮次关闭码=%d，期望=%d，err=%v", got, tt.wantStatus, readErr)
			}
			if evaluator.calls.Load() != 2 || preconsumeCalls.Load() != 1 || dispatchCalls.Load() != 1 {
				t.Fatalf("后续轮次拒绝不得新增预扣或发送: guard=%d preconsume=%d dispatch=%d", evaluator.calls.Load(), preconsumeCalls.Load(), dispatchCalls.Load())
			}
		})
	}
}

func installResponsesWSPromptGuardConfig(t *testing.T) {
	t.Helper()
	basecommon.OptionMapRWMutex.Lock()
	hadMap := basecommon.OptionMap != nil
	if basecommon.OptionMap == nil {
		basecommon.OptionMap = map[string]string{}
	}
	previous, hadValue := basecommon.OptionMap[promptaudit.ConfigOptionKey]
	basecommon.OptionMap[promptaudit.ConfigOptionKey] = fmt.Sprintf(`{"enabled":true,"blocking_enabled":true,"store_pass_events":false,"strategy":"priority","worker_count":1,"queue_capacity":100,"scanners":["Jailbreak"],"audit_group_mode":"all","endpoints":[{"id":"guard","name":"guard","base_url":"http://127.0.0.1:18080","timeout_ms":1000,"input_limit":1024,"weight":100,"enabled":true}],"config_version":%d}`, 11)
	basecommon.OptionMapRWMutex.Unlock()
	promptaudit.ClearConfigCache()
	t.Cleanup(func() {
		basecommon.OptionMapRWMutex.Lock()
		if hadValue {
			basecommon.OptionMap[promptaudit.ConfigOptionKey] = previous
		} else {
			delete(basecommon.OptionMap, promptaudit.ConfigOptionKey)
			if !hadMap && len(basecommon.OptionMap) == 0 {
				basecommon.OptionMap = nil
			}
		}
		basecommon.OptionMapRWMutex.Unlock()
		promptaudit.ClearConfigCache()
	})
}
