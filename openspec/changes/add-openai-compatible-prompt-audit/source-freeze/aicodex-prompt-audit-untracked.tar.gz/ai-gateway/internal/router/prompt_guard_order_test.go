package router

import (
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

func TestRelayRouterPromptGuardPrecedesDistribution(t *testing.T) {
	_, current, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("无法定位测试文件")
	}
	source, err := os.ReadFile(filepath.Join(filepath.Dir(current), "relay-router.go"))
	if err != nil {
		t.Fatalf("读取 relay-router.go: %v", err)
	}
	text := string(source)
	wants := []string{
		"httpRouter.Use(middleware.ModelRequestRateLimit())\n\t\thttpRouter.Use(promptaudit.HTTPGuardMiddleware())\n\t\thttpRouter.Use(middleware.Distribute())",
		"responsesAliasRouter.Use(middleware.ModelRequestRateLimit())\n\tresponsesAliasRouter.Use(promptaudit.HTTPGuardMiddleware(types.RelayFormatOpenAIResponses))\n\tresponsesAliasRouter.Use(middleware.Distribute())",
		"relayGeminiRouter.Use(middleware.ModelRequestRateLimit())\n\trelayGeminiRouter.Use(promptaudit.HTTPGuardMiddleware(types.RelayFormatGemini))\n\trelayGeminiRouter.Use(middleware.Distribute())",
	}
	for _, want := range wants {
		if !strings.Contains(text, want) {
			t.Fatalf("6068 同步门禁顺序不符合约束，缺少片段:\n%s", want)
		}
	}
}

func TestVideoRouterPromptGuardPrecedesDistribution(t *testing.T) {
	_, current, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("无法定位测试文件")
	}
	source, err := os.ReadFile(filepath.Join(filepath.Dir(current), "video-router.go"))
	if err != nil {
		t.Fatalf("读取 video-router.go: %v", err)
	}
	text := string(source)
	for _, groupName := range []string{"videoV1Router", "klingV1Router", "jimengOfficialGroup"} {
		useStart := strings.Index(text, groupName+".Use(")
		if useStart < 0 {
			t.Fatalf("6068 文本任务路由缺少中间件组: %s", groupName)
		}
		useEndOffset := strings.Index(text[useStart:], "\n\t)")
		if useEndOffset < 0 {
			t.Fatalf("6068 文本任务路由中间件组不完整: %s", groupName)
		}
		middlewares := text[useStart : useStart+useEndOffset]
		concurrency := strings.Index(middlewares, "UserConcurrencyLimit")
		guard := strings.Index(middlewares, "HTTPGuardMiddleware")
		distribute := strings.Index(middlewares, "Distribute")
		admission := strings.Index(middlewares, "PriorityAdmission")
		enqueue := strings.Index(middlewares, "HTTPEnqueueMiddleware")
		if concurrency < 0 || guard < 0 || distribute < 0 || admission < 0 || enqueue < 0 ||
			!(concurrency < guard && guard < distribute && distribute < admission && admission < enqueue) {
			t.Fatalf("6068 文本任务双模式顺序不符合约束: group=%s concurrency=%d guard=%d distribute=%d admission=%d enqueue=%d", groupName, concurrency, guard, distribute, admission, enqueue)
		}
	}
}

func TestRelayTaskGroupsKeepAsyncEnqueueAfterPromptGuard(t *testing.T) {
	_, current, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("无法定位测试文件")
	}
	source, err := os.ReadFile(filepath.Join(filepath.Dir(current), "relay-router.go"))
	if err != nil {
		t.Fatalf("读取 relay-router.go: %v", err)
	}
	text := string(source)
	for _, groupName := range []string{"relaySunoRouter", "relayMjRouter"} {
		useStart := strings.Index(text, groupName+".Use(middleware.TokenAuth()")
		if useStart < 0 {
			t.Fatalf("6068 任务路由缺少中间件组: %s", groupName)
		}
		lineEndOffset := strings.Index(text[useStart:], "\n")
		if lineEndOffset < 0 {
			t.Fatalf("6068 任务路由中间件组不完整: %s", groupName)
		}
		middlewares := text[useStart : useStart+lineEndOffset]
		guard := strings.Index(middlewares, "HTTPGuardMiddleware")
		distribute := strings.Index(middlewares, "Distribute")
		admission := strings.Index(middlewares, "PriorityAdmission")
		enqueue := strings.Index(middlewares, "HTTPEnqueueMiddleware")
		if guard < 0 || distribute < 0 || admission < 0 || enqueue < 0 ||
			!(guard < distribute && distribute < admission && admission < enqueue) {
			t.Fatalf("6068 任务路由双模式顺序不符合约束: group=%s guard=%d distribute=%d admission=%d enqueue=%d", groupName, guard, distribute, admission, enqueue)
		}
	}
}
