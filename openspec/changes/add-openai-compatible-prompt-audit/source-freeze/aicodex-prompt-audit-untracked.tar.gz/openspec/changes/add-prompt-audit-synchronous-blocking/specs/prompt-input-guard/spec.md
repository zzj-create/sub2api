## ADDED Requirements

### Requirement: 同步阻止必须由显式配置启用

系统 SHALL 仅在提示词审计已启用且 `blocking_enabled=true` 时，对处于审计分组范围内的请求执行同步提示词门禁。旧配置缺少 `blocking_enabled` 时 MUST 归一为 `false`。

#### Scenario: 审计开启但同步阻止关闭
- **WHEN** 配置为 `enabled=true` 且 `blocking_enabled=false`
- **THEN** 系统 MUST 保持现有异步只审计行为
- **AND** 主模型请求 MUST NOT 等待 Guard 判定
- **AND** 异步审计结果 MUST NOT 改变已经完成的转发结果

#### Scenario: 审计与同步阻止同时开启
- **WHEN** 配置为 `enabled=true` 且 `blocking_enabled=true`
- **THEN** 系统 MUST 对处于审计分组范围内的受支持请求执行同步 Guard 判定
- **AND** 请求只有在同步判定允许后才可进入后续模型执行链路

#### Scenario: 审计关闭时提交同步阻止
- **WHEN** 管理 API 收到 `enabled=false` 且 `blocking_enabled=true` 的保存请求
- **THEN** 系统 MUST 拒绝保存并返回 `prompt_guard_requires_audit_enabled`
- **AND** 运行时 MUST NOT 出现“审计关闭但同步阻止生效”的不一致状态

#### Scenario: 请求分组不在审计范围
- **WHEN** `audit_group_mode=selected` 且请求运行时分组不在 `audit_groups` 中
- **THEN** 系统 MUST 按现有分组范围规则跳过同步门禁
- **AND** 系统 MUST 输出不含提示词正文的稳定跳过原因

### Requirement: 同步门禁必须早于渠道、计费与上游副作用

系统 SHALL 在鉴权、用户并发和请求速率保护之后执行同步门禁，并 MUST 在渠道选择、优先级 admission、计费预扣、上游连接和请求转发之前得到最终判定。

#### Scenario: 提示词命中 Block
- **WHEN** 同步 Guard 对请求返回最终 `Block` 判定
- **THEN** 系统 MUST 阻止该请求
- **AND** 系统 MUST NOT 选择上游渠道
- **AND** 系统 MUST NOT 执行计费预扣
- **AND** 系统 MUST NOT 建立上游请求或进入渠道重试

#### Scenario: 提示词得到 Allow
- **WHEN** 同步 Guard 完成全部必要分片并返回最终 `Allow`
- **THEN** 系统 MUST 允许请求继续进入原有渠道、计费和转发链路
- **AND** 系统 MUST 保持原有协议转换、计费和上游重试语义

#### Scenario: 提示词得到 Warn
- **WHEN** 同步 Guard 返回 `Controversial` 或等价 `Warn` 判定且没有 Block
- **THEN** 系统 MUST 允许请求继续转发
- **AND** 系统 MUST 记录 `Flag` 审计事实
- **AND** 系统 MUST NOT 把未达到 Block 的结果提升为硬阻止

#### Scenario: 流式 HTTP 请求进入门禁
- **WHEN** 客户端请求 SSE 或其他流式模型响应
- **THEN** 系统 MUST 在 Guard 判定完成前不写出流式响应头或首字节
- **AND** Block 或 unavailable MUST 使用普通协议错误结束请求

### Requirement: 同步阻止必须采用稳定的 fail-closed 语义

系统 SHALL 在同步阻止启用时采用 fail-closed。Guard 节点超时、不可达、容量饱和、全部故障切换失败或响应无法严格解析时，系统 MUST 拒绝请求且不得降级为异步放行。

#### Scenario: Guard 命中策略阻止
- **WHEN** 最终判定为 Block
- **THEN** HTTP 请求 MUST 返回 403
- **AND** 错误码 MUST 为 `prompt_guard_blocked`
- **AND** 错误响应 MUST 只包含通用消息、稳定错误码和 `request_id`

#### Scenario: Guard 节点全部不可用
- **WHEN** 所有启用的 Guard 节点在同步总 deadline 内均无法产生合法结果
- **THEN** HTTP 请求 MUST 返回 503
- **AND** 错误码 MUST 为 `prompt_guard_unavailable`
- **AND** 请求 MUST NOT 被异步审计模式兜底放行

#### Scenario: Guard 返回非法响应
- **WHEN** Guard 响应缺少唯一合法的 `Safety` 或包含无法接受的结构
- **THEN** HTTP 请求 MUST 返回 503
- **AND** 错误码 MUST 为 `prompt_guard_invalid_response`
- **AND** 系统 MUST NOT 把该响应解释为 Safe

#### Scenario: 关闭同步阻止进行回滚
- **WHEN** 管理员将 `blocking_enabled` 关闭并保存
- **THEN** 新请求 MUST 恢复异步只审计语义
- **AND** Guard 不可用 MUST 不再影响主模型请求结果

### Requirement: Qwen3Guard 分类必须由服务端确定性映射为阻止动作

系统 SHALL 把 Qwen3Guard 视为分类器，并由服务端根据严格解析后的 Safety、启用类别和固定规则决定 Allow、Warn 或 Block。系统 MUST NOT 使用未校准的 scanner score 作为阻止阈值。

#### Scenario: Safe 分类
- **WHEN** Guard 返回唯一合法的 `Safety: Safe`
- **THEN** 服务端 MUST 生成 Allow

#### Scenario: Controversial 未命中已启用高风险类别
- **WHEN** Guard 返回唯一合法的 `Safety: Controversial`
- **AND** 未命中已启用的 `Jailbreak`、`PII` 或 `Suicide & Self-Harm`
- **THEN** 服务端 MUST 生成 Warn
- **AND** 请求 MUST 在没有其他 Block 结果时继续转发

#### Scenario: Controversial 命中已启用高风险类别
- **WHEN** Guard 返回唯一合法的 `Safety: Controversial`
- **AND** 至少命中一个已启用的 `Jailbreak`、`PII` 或 `Suicide & Self-Harm`
- **THEN** 服务端 MUST 保持现有策略并生成 Block
- **AND** 同步模式 MUST 阻止请求，避免相对异步审计基线发生安全降级

#### Scenario: Controversial 高风险类别被明确关闭
- **WHEN** Guard 返回唯一合法的 `Safety: Controversial`
- **AND** 命中的 `Jailbreak`、`PII` 或 `Suicide & Self-Harm` 均被管理员明确关闭
- **THEN** 服务端 MUST NOT 因已关闭类别生成同步 Block
- **AND** 系统 MUST 保留 Warn 审计事实用于管理员复核

#### Scenario: Unsafe 命中已启用类别
- **WHEN** Guard 返回 `Safety: Unsafe` 且至少一个分类位于管理员启用的检测类别中
- **THEN** 服务端 MUST 生成 Block

#### Scenario: Unsafe 没有可解析类别
- **WHEN** Guard 返回 `Safety: Unsafe` 但没有可解析的已知类别
- **THEN** 服务端 MUST 生成 Block
- **AND** 审计类别 MUST 包含稳定值 `unknown_unsafe`

#### Scenario: Unsafe 仅命中未启用类别
- **WHEN** Guard 返回 `Safety: Unsafe` 且全部已知分类均被管理员明确关闭
- **THEN** 服务端 MUST NOT 因这些已关闭分类生成同步 Block
- **AND** 系统 MUST 保留脱敏审计事实用于管理员复核

#### Scenario: Guard 输出重复 Safety
- **WHEN** Guard 输出多个 `Safety` 字段、额外非空说明或未知 Safety 值
- **THEN** 解析器 MUST 拒绝该响应
- **AND** 同步门禁 MUST 按 `prompt_guard_invalid_response` fail-closed

### Requirement: 同步门禁必须完整扫描所有必要输入分片

系统 SHALL 复用现有协议输入提取、最新用户输入优先和 Unicode 分片语义。任一分片 Block 时系统 MAY 立即早停并阻止；只有全部必要非空分片成功完成且均未 Block 时才可放行。

#### Scenario: 最新一轮输入命中风险
- **WHEN** 多轮请求的最新用户输入命中 Block
- **THEN** 系统 MUST 优先扫描最新一轮并阻止请求
- **AND** 系统 MAY 不再扫描剩余历史分片

#### Scenario: 风险只位于历史分片
- **WHEN** 最新输入安全但风险内容位于后续历史分片
- **THEN** 系统 MUST 扫描该历史分片
- **AND** 最终请求 MUST 被阻止

#### Scenario: 某个必要分片失败
- **WHEN** 任一尚未得到结果的必要分片超时或返回非法响应
- **THEN** 系统 MUST NOT 使用其他分片组成部分 Allow
- **AND** 同步门禁 MUST 按 unavailable 或 invalid response 拒绝请求

#### Scenario: 内部分片边界处理
- **WHEN** 系统构造最新输入优先的内部边界
- **THEN** 该边界 MUST NOT 发送给 Guard
- **AND** 该边界 MUST NOT 进入 prompt hash、预览、日志或错误响应

### Requirement: 6068 与 9068 的同步阻止行为必须一致

系统 SHALL 让 `6068` 应用入口与 `9068` 数据面入口复用同一同步判定契约，并覆盖当前提示词审计支持的 OpenAI Chat/Responses、Claude Messages、Gemini 和文本任务请求。

#### Scenario: 相同 OpenAI Chat 请求进入不同端口
- **WHEN** 等价的 Block 请求分别通过 `6068` 和 `9068` 的 `/v1/chat/completions` 进入
- **THEN** 两个入口 MUST 返回等价的 `prompt_guard_blocked` 语义
- **AND** 两个入口的上游调用和预扣次数 MUST 均为 0

#### Scenario: OpenAI Responses HTTP 请求被阻止
- **WHEN** `/v1/responses` 或等价 Responses alias 的用户输入命中 Block
- **THEN** 系统 MUST 在创建上游 Responses 请求前拒绝
- **AND** 入口别名 MUST NOT 形成旁路

#### Scenario: Claude 或 Gemini 请求被阻止
- **WHEN** Claude Messages 或 Gemini 文本输入命中 Block
- **THEN** 系统 MUST 使用对应协议的错误 envelope 返回拒绝
- **AND** 稳定错误码语义 MUST 与 OpenAI 入口一致

#### Scenario: 不含可扫描文本的请求
- **WHEN** 受支持入口的合法请求不包含任何非空可扫描文本
- **THEN** 系统 MUST 记录稳定跳过原因
- **AND** 系统 MUST 按原有请求语义继续处理

### Requirement: Responses WebSocket 必须按轮次执行同步门禁

系统 SHALL 对 Responses WebSocket 的首个和后续每个 `response.create` 帧执行同步门禁，并 MUST 在本轮计费预扣和客户端帧转发到上游之前完成判定。

#### Scenario: 首轮提示词被阻止
- **WHEN** Responses WebSocket 首个 `response.create` 命中 Block
- **THEN** 系统 MUST NOT 创建首轮 billing pending turn
- **AND** 系统 MUST NOT 拨号或发送请求到上游
- **AND** 系统 MUST 使用 close code `4403` 和 reason `prompt_guard_blocked` 关闭连接

#### Scenario: 后续轮次提示词被阻止
- **WHEN** 已建立的 Responses WebSocket 收到后续 `response.create` 且该轮命中 Block
- **THEN** 该帧 MUST NOT 发送给上游
- **AND** 系统 MUST NOT 为该轮新增预扣
- **AND** 系统 MUST 使用 close code `4403` 和 reason `prompt_guard_blocked` 关闭连接

#### Scenario: WebSocket Guard 不可用
- **WHEN** 首轮或后续轮次 Guard 不可用或响应非法
- **THEN** 对应帧 MUST NOT 发送给上游
- **AND** 系统 MUST 使用 close code `1013` 关闭连接
- **AND** close reason MUST 为 `prompt_guard_unavailable` 或 `prompt_guard_invalid_response`

### Requirement: 同步判定结果必须复用到脱敏审计事件

系统 SHALL 在同步模式中把已完成的归一化判定交给结果记录路径，禁止为同一请求再次调用 Guard。结果记录路径 MUST NOT 接收或持久化完整原始提示词。

#### Scenario: 同步 Block 结果被记录
- **WHEN** 同步门禁完成 Block 判定
- **THEN** 系统 MUST 尝试创建可通过 `request_id` 关联的脱敏审计事件
- **AND** 事件 MUST 包含判定、分类、scanner、policy、耗时和 prompt hash
- **AND** 系统 MUST NOT 再次调用 Guard

#### Scenario: 同步 Allow 结果被记录
- **WHEN** 同步门禁完成 Allow 判定且 `store_pass_events=true`
- **THEN** 系统 MUST 尝试保存通过事件
- **AND** 通过事件 MUST NOT 包含完整原始提示词

#### Scenario: 结果记录失败
- **WHEN** 同步判定已经完成但审计结果记录失败
- **THEN** 系统 MUST 输出 `prompt_guard.result_record_failed`
- **AND** 记录失败 MUST NOT 撤销既有 Block
- **AND** 记录失败 MUST NOT 把既有 Allow 改为 unavailable

### Requirement: 同步门禁必须提供版本化且脱敏的观测信号

系统 SHALL 为配置加载、判定开始、允许、阻止、失败和结果记录失败输出结构化日志与指标，并 MUST 能关联控制面期望版本和当前实例生效版本。

#### Scenario: 同步请求被阻止
- **WHEN** 系统执行 Block
- **THEN** `prompt_guard.blocked` 日志 MUST 包含 `request_id`、用户与分组标识、协议、入口、模型、`config_version`、policy、Guard 节点 ID、判定、分片数和耗时
- **AND** 日志 MUST 包含 `upstream_dispatched=false` 与 `billing_preconsumed=false`
- **AND** 日志 MUST NOT 包含提示词正文、API Key、Token、Authorization 或完整 Guard URL

#### Scenario: 配置版本加载
- **WHEN** 数据面实例原子加载新的提示词门禁配置
- **THEN** 系统 MUST 输出 `prompt_guard.config_loaded`
- **AND** 运行态 MUST 返回期望版本、当前实例生效版本、`blocking_enabled`、加载时间和最近加载错误

#### Scenario: 配置失效通知降级
- **WHEN** 多实例配置失效通知不可用且系统回退到有界缓存刷新
- **THEN** 系统 MUST 输出 `prompt_guard.config_reload_degraded`
- **AND** 日志 MUST 包含稳定错误码和最后有效 `config_version`

### Requirement: Guard 出站访问必须受安全边界约束

系统 SHALL 把 Guard 节点作为接收完整待分类文本的高敏出站边界，对 scheme、目标地址、重定向、超时、响应大小和并发执行限制。

#### Scenario: 配置公网 HTTP Guard
- **WHEN** 管理员尝试保存公网 `http://` Guard 地址
- **THEN** 系统 MUST 拒绝配置
- **AND** 错误响应 MUST NOT 回显 API Key

#### Scenario: 配置本机或受控私网 Guard
- **WHEN** 管理员配置显式允许的本机或受控私网 HTTP Guard
- **THEN** 系统 MAY 接受该配置
- **AND** 系统 MUST 保持提示词、认证信息和目标地址日志脱敏

#### Scenario: Guard 返回重定向到受限地址
- **WHEN** Guard HTTP 响应尝试重定向到 link-local、云元数据或其他未授权地址
- **THEN** 客户端 MUST 拒绝重定向
- **AND** 同步门禁 MUST 按 unavailable fail-closed
