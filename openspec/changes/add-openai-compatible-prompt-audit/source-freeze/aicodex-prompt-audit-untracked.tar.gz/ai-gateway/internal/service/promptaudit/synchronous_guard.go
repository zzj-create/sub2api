package promptaudit

import (
	"context"
	"errors"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gin-gonic/gin"
	appent "github.com/mt21625457/aicodex/ent"
	"github.com/mt21625457/aicodex/internal/common"
	"github.com/mt21625457/aicodex/internal/constant"
	"github.com/mt21625457/aicodex/internal/gatewaycore"
	"github.com/mt21625457/aicodex/internal/types"
)

const (
	promptGuardGlobalConcurrency  = 64
	promptGuardPerNodeConcurrency = 16
	promptGuardRecordConcurrency  = 32
)

type promptGuardMetrics struct {
	total           atomic.Int64
	allowed         atomic.Int64
	flagged         atomic.Int64
	blocked         atomic.Int64
	unavailable     atomic.Int64
	invalidResponse atomic.Int64
	timeouts        atomic.Int64
	failovers       atomic.Int64
	bulkheadFull    atomic.Int64
	recordFailures  atomic.Int64
	latencyBuckets  [11]atomic.Int64
}

type PromptGuardMetricsSnapshot struct {
	Total           int64            `json:"total"`
	Allowed         int64            `json:"allowed"`
	Flagged         int64            `json:"flagged"`
	Blocked         int64            `json:"blocked"`
	Unavailable     int64            `json:"unavailable"`
	InvalidResponse int64            `json:"invalid_response"`
	Timeouts        int64            `json:"timeouts"`
	Failovers       int64            `json:"failovers"`
	BulkheadFull    int64            `json:"bulkhead_full"`
	RecordFailures  int64            `json:"record_failures"`
	LatencyBuckets  map[string]int64 `json:"latency_buckets"`
}

var promptGuardLatencyBucketUpperBounds = [...]int64{25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 30000}

var defaultPromptGuardMetrics promptGuardMetrics

var promptGuardRecordSlots = make(chan struct{}, promptGuardRecordConcurrency)

func GetPromptGuardMetricsSnapshot() PromptGuardMetricsSnapshot {
	snapshot := PromptGuardMetricsSnapshot{
		Total:           defaultPromptGuardMetrics.total.Load(),
		Allowed:         defaultPromptGuardMetrics.allowed.Load(),
		Flagged:         defaultPromptGuardMetrics.flagged.Load(),
		Blocked:         defaultPromptGuardMetrics.blocked.Load(),
		Unavailable:     defaultPromptGuardMetrics.unavailable.Load(),
		InvalidResponse: defaultPromptGuardMetrics.invalidResponse.Load(),
		Timeouts:        defaultPromptGuardMetrics.timeouts.Load(),
		Failovers:       defaultPromptGuardMetrics.failovers.Load(),
		BulkheadFull:    defaultPromptGuardMetrics.bulkheadFull.Load(),
		RecordFailures:  defaultPromptGuardMetrics.recordFailures.Load(),
		LatencyBuckets:  make(map[string]int64, len(promptGuardLatencyBucketUpperBounds)+1),
	}
	for index, upperBound := range promptGuardLatencyBucketUpperBounds {
		snapshot.LatencyBuckets[(time.Duration(upperBound) * time.Millisecond).String()] = defaultPromptGuardMetrics.latencyBuckets[index].Load()
	}
	snapshot.LatencyBuckets["+Inf"] = defaultPromptGuardMetrics.latencyBuckets[len(promptGuardLatencyBucketUpperBounds)].Load()
	return snapshot
}

func recordPromptGuardLatency(latency time.Duration) {
	milliseconds := latency.Milliseconds()
	for index, upperBound := range promptGuardLatencyBucketUpperBounds {
		if milliseconds <= upperBound {
			defaultPromptGuardMetrics.latencyBuckets[index].Add(1)
			return
		}
	}
	defaultPromptGuardMetrics.latencyBuckets[len(promptGuardLatencyBucketUpperBounds)].Add(1)
}

type SynchronousEvaluator struct {
	scanner     PromptScanner
	globalSlots chan struct{}
	nodeMu      sync.Mutex
	nodeSlots   map[string]chan struct{}
}

func NewSynchronousEvaluator(scanner PromptScanner) *SynchronousEvaluator {
	if scanner == nil {
		scanner = NewOpenAICompatibleClient(newSecureGuardHTTPClient())
	}
	return &SynchronousEvaluator{
		scanner:     scanner,
		globalSlots: make(chan struct{}, promptGuardGlobalConcurrency),
		nodeSlots:   make(map[string]chan struct{}),
	}
}

func (e *SynchronousEvaluator) nodeSemaphore(endpointID string) chan struct{} {
	endpointID = strings.TrimSpace(endpointID)
	if endpointID == "" {
		endpointID = "default"
	}
	e.nodeMu.Lock()
	defer e.nodeMu.Unlock()
	if semaphore, ok := e.nodeSlots[endpointID]; ok {
		return semaphore
	}
	semaphore := make(chan struct{}, promptGuardPerNodeConcurrency)
	e.nodeSlots[endpointID] = semaphore
	return semaphore
}

func (e *SynchronousEvaluator) Evaluate(ctx context.Context, input gatewaycore.PromptGuardInput) gatewaycore.PromptGuardResult {
	cfg, err := loadCachedConfig(ctx)
	if err != nil {
		return promptGuardUnavailableResult(gatewaycore.PromptGuardErrorUnavailable, 0)
	}
	return e.evaluateWithConfig(ctx, cfg, input)
}

func (e *SynchronousEvaluator) evaluateWithConfig(ctx context.Context, cfg Config, input gatewaycore.PromptGuardInput) gatewaycore.PromptGuardResult {
	startedAt := time.Now()
	defaultPromptGuardMetrics.total.Add(1)
	if !cfg.Enabled || !cfg.BlockingEnabled {
		return promptGuardAllowResult(startedAt)
	}
	endpoints := cfg.EnabledEndpoints()
	if len(endpoints) == 0 {
		return e.finishUnavailable(input, startedAt, gatewaycore.PromptGuardErrorUnavailable, "no_enabled_endpoint")
	}
	select {
	case e.globalSlots <- struct{}{}:
		defer func() { <-e.globalSlots }()
	default:
		defaultPromptGuardMetrics.bulkheadFull.Add(1)
		return e.finishUnavailable(input, startedAt, gatewaycore.PromptGuardErrorUnavailable, "global_bulkhead_full")
	}

	deadline := time.Duration(normalizeTimeoutMSForProtocol(endpoints[0].Protocol, endpoints[0].TimeoutMS)) * time.Millisecond
	evalCtx, cancel := context.WithTimeout(ctx, deadline)
	defer cancel()
	LogInfoEvent("prompt_guard.evaluation_started", promptGuardLogFields(input, cfg, gatewaycore.PromptGuardResult{
		Decision: gatewaycore.PromptGuardDecisionUnavailable,
	}, "started", "")...)

	lastCode := gatewaycore.PromptGuardErrorUnavailable
	for index, endpoint := range endpoints {
		if err := validateGuardBaseURL(firstNonEmptyString(endpoint.BaseURL, endpoint.ScanURL)); err != nil {
			lastCode = gatewaycore.PromptGuardErrorUnavailable
			break
		}
		nodeSlots := e.nodeSemaphore(endpoint.ID)
		select {
		case nodeSlots <- struct{}{}:
		case <-evalCtx.Done():
			defaultPromptGuardMetrics.timeouts.Add(1)
			return e.finishUnavailable(input, startedAt, gatewaycore.PromptGuardErrorUnavailable, "deadline_exceeded")
		default:
			defaultPromptGuardMetrics.bulkheadFull.Add(1)
			if index < len(endpoints)-1 {
				defaultPromptGuardMetrics.failovers.Add(1)
				continue
			}
			return e.finishUnavailable(input, startedAt, gatewaycore.PromptGuardErrorUnavailable, "node_bulkhead_full")
		}

		result, scanErr := e.scanner.ScanPrompt(evalCtx, endpoint, input.Text, cfg.Scanners, ScanPromptContext{
			RequestID:   input.RequestID,
			UserID:      input.UserID,
			TokenID:     input.TokenID,
			Endpoint:    input.Endpoint,
			Protocol:    input.Protocol,
			Model:       input.Model,
			Group:       input.Group,
			StopOnBlock: true,
		})
		<-nodeSlots
		if scanErr != nil {
			llmErr := asLLMGuardError(scanErr)
			if errors.Is(evalCtx.Err(), context.DeadlineExceeded) || (llmErr != nil && llmErr.Code == "openai_guard_timeout") {
				defaultPromptGuardMetrics.timeouts.Add(1)
			}
			if llmErr != nil && llmErr.Code == "openai_guard_invalid_response" {
				defaultPromptGuardMetrics.invalidResponse.Add(1)
				lastCode = gatewaycore.PromptGuardErrorInvalidResponse
				break
			}
			lastCode = gatewaycore.PromptGuardErrorUnavailable
			if llmErr != nil && !llmErr.Retryable {
				break
			}
			if index < len(endpoints)-1 && evalCtx.Err() == nil {
				defaultPromptGuardMetrics.failovers.Add(1)
				continue
			}
			break
		}
		return e.finishResult(input, cfg, endpoint, result, startedAt)
	}
	return e.finishUnavailable(input, startedAt, lastCode, "guard_nodes_exhausted")
}

func (e *SynchronousEvaluator) finishResult(input gatewaycore.PromptGuardInput, cfg Config, endpoint EndpointConfig, scan LLMGuardScanResult, startedAt time.Time) gatewaycore.PromptGuardResult {
	normalized := NormalizeLLMGuardResult(scan)
	decision := gatewaycore.PromptGuardDecisionAllow
	allow := true
	switch normalized.Decision {
	case DecisionCritical:
		decision = gatewaycore.PromptGuardDecisionBlock
		allow = false
		defaultPromptGuardMetrics.blocked.Add(1)
	case DecisionFlag:
		decision = gatewaycore.PromptGuardDecisionFlag
		defaultPromptGuardMetrics.flagged.Add(1)
	default:
		defaultPromptGuardMetrics.allowed.Add(1)
	}
	result := gatewaycore.PromptGuardResult{
		Decision:           decision,
		Action:             normalized.Action,
		Categories:         append([]string(nil), normalized.Categories...),
		ObservedCategories: observedQwen3GuardCategories(scan.Evidence),
		MatchedScanners:    append([]string(nil), normalized.MatchedScanners...),
		ScannerScores:      cloneScannerScores(normalized.ScannerScores),
		ScannerBackend:     normalized.ScannerBackend,
		ScannerVersion:     normalized.ScannerVersion,
		PolicyID:           normalized.PolicyID,
		PolicyVersion:      normalized.PolicyVersion,
		GuardEndpointID:    endpoint.ID,
		ChunkTotal:         len(splitPromptByRuneLimit(input.Text, endpoint.InputLimit)),
		Latency:            time.Since(startedAt),
		AllowNextStage:     allow,
	}
	recordPromptGuardLatency(result.Latency)
	if !allow {
		result.ErrorCode = gatewaycore.PromptGuardErrorBlocked
	}
	eventName := "prompt_guard.allowed"
	if decision == gatewaycore.PromptGuardDecisionBlock {
		eventName = "prompt_guard.blocked"
	}
	LogInfoEvent(eventName, promptGuardLogFields(input, cfg, result, "completed", result.ErrorCode)...)
	return result
}

func observedQwen3GuardCategories(evidence ScannerEvidence) []string {
	items := evidence["_guard_observed_categories"]
	out := make([]string, 0, len(items))
	seen := make(map[string]struct{}, len(items))
	for _, item := range items {
		category := strings.TrimSpace(item.Category)
		if category == "" {
			category = strings.TrimSpace(item.ScannerID)
		}
		if category == "" {
			continue
		}
		if _, ok := seen[category]; ok {
			continue
		}
		seen[category] = struct{}{}
		out = append(out, category)
	}
	return out
}

func (e *SynchronousEvaluator) finishUnavailable(input gatewaycore.PromptGuardInput, startedAt time.Time, code string, reason string) gatewaycore.PromptGuardResult {
	defaultPromptGuardMetrics.unavailable.Add(1)
	result := promptGuardUnavailableResult(code, time.Since(startedAt))
	recordPromptGuardLatency(result.Latency)
	LogWarnEvent("prompt_guard.failed", append(promptGuardLogFields(input, Config{ConfigVersion: input.ConfigVersion}, result, "failed", code), Field("reason", reason))...)
	return result
}

func promptGuardAllowResult(startedAt time.Time) gatewaycore.PromptGuardResult {
	return gatewaycore.PromptGuardResult{
		Decision:       gatewaycore.PromptGuardDecisionAllow,
		Action:         "Allow",
		Latency:        time.Since(startedAt),
		AllowNextStage: true,
	}
}

func promptGuardUnavailableResult(code string, latency time.Duration) gatewaycore.PromptGuardResult {
	if code == "" {
		code = gatewaycore.PromptGuardErrorUnavailable
	}
	return gatewaycore.PromptGuardResult{
		Decision:       gatewaycore.PromptGuardDecisionUnavailable,
		Action:         "Unavailable",
		Latency:        latency,
		ErrorCode:      code,
		AllowNextStage: false,
	}
}

func cloneScannerScores(in map[string]float64) map[string]float64 {
	out := make(map[string]float64, len(in))
	for key, value := range in {
		out[key] = value
	}
	return out
}

func promptGuardLogFields(input gatewaycore.PromptGuardInput, cfg Config, result gatewaycore.PromptGuardResult, status string, errorCode string) []LogField {
	return []LogField{
		Field("status", status),
		Field("request_id", input.RequestID),
		Field("user_id", input.UserID),
		Field("token_id", input.TokenID),
		Field("group", input.Group),
		Field("protocol", input.Protocol),
		Field("endpoint", input.Endpoint),
		Field("model", input.Model),
		Field("config_version", normalizeConfigVersion(cfg.ConfigVersion)),
		Field("policy_id", result.PolicyID),
		Field("policy_version", result.PolicyVersion),
		Field("guard_endpoint_id", result.GuardEndpointID),
		Field("decision", result.Decision),
		Field("action", result.Action),
		Field("chunk_total", result.ChunkTotal),
		Field("latency_ms", result.Latency.Milliseconds()),
		Field("error_code", errorCode),
		Field("stage", input.Stage),
		Field("upstream_dispatched", false),
		Field("billing_preconsumed", false),
	}
}

var (
	promptGuardEvaluatorMu sync.RWMutex
	promptGuardEvaluator   gatewaycore.PromptGuardEvaluator = NewSynchronousEvaluator(nil)
)

func currentPromptGuardEvaluator() gatewaycore.PromptGuardEvaluator {
	promptGuardEvaluatorMu.RLock()
	defer promptGuardEvaluatorMu.RUnlock()
	return promptGuardEvaluator
}

// SetPromptGuardEvaluatorForTesting 允许协议与副作用测试注入确定性判定器。
func SetPromptGuardEvaluatorForTesting(evaluator gatewaycore.PromptGuardEvaluator) func() {
	promptGuardEvaluatorMu.Lock()
	previous := promptGuardEvaluator
	if evaluator == nil {
		evaluator = NewSynchronousEvaluator(nil)
	}
	promptGuardEvaluator = evaluator
	promptGuardEvaluatorMu.Unlock()
	return func() {
		promptGuardEvaluatorMu.Lock()
		promptGuardEvaluator = previous
		promptGuardEvaluatorMu.Unlock()
	}
}

type PromptGuardCheck struct {
	Enabled    bool
	Allowed    bool
	StatusCode int
	ErrorCode  string
	Result     gatewaycore.PromptGuardResult
}

func EvaluatePromptGuardBody(c *gin.Context, relayFormat types.RelayFormat, path string, body []byte, stage string, allowRepeated bool) PromptGuardCheck {
	check := PromptGuardCheck{Allowed: true}
	if c == nil {
		return check
	}
	cfg, err := loadCachedConfig(c.Request.Context())
	if err != nil {
		check.Enabled = true
		check.Allowed = false
		check.StatusCode = http.StatusServiceUnavailable
		check.ErrorCode = gatewaycore.PromptGuardErrorUnavailable
		check.Result = promptGuardUnavailableResult(check.ErrorCode, 0)
		return check
	}
	if !cfg.Enabled {
		return check
	}
	if ok, reason := cfg.ShouldAuditGroup(resolvePromptAuditRuntimeGroup(c)); !ok {
		LogInfoEvent("prompt_guard.evaluation_skipped",
			Field("status", "skipped"), Field("reason", reason), Field("request_id", c.GetString(common.RequestIdKey)),
			Field("group", resolvePromptAuditRuntimeGroup(c)), Field("config_version", cfg.ConfigVersion), Field("stage", stage))
		return check
	}
	if !cfg.BlockingEnabled {
		if allowRepeated {
			MaybeEnqueueTurnFromGateway(c, relayFormat, body)
		}
		return check
	}
	check.Enabled = true
	snapshotContext := promptGuardSnapshotContext(c)
	snapshot, ok, err := ExtractSnapshotByRelayFormat(relayFormat, path, body, snapshotContext)
	if err != nil {
		check.Allowed = false
		check.StatusCode = http.StatusServiceUnavailable
		check.ErrorCode = gatewaycore.PromptGuardErrorUnavailable
		check.Result = promptGuardUnavailableResult(check.ErrorCode, 0)
		LogWarnEvent("prompt_guard.failed", promptGuardInputFailureFields(c, cfg, relayFormat, path, stage, "snapshot_extract_failed")...)
		return check
	}
	if !ok || strings.TrimSpace(snapshot.ScanText) == "" {
		reason := "snapshot_unsupported"
		if ok {
			reason = "snapshot_user_input_empty"
		}
		LogInfoEvent("prompt_guard.evaluation_skipped", promptGuardInputFailureFields(c, cfg, relayFormat, path, stage, reason)...)
		return check
	}
	input := gatewaycore.PromptGuardInput{
		RequestID: snapshot.RequestID, UserID: snapshot.UserID, TokenID: snapshot.TokenID,
		Group: snapshot.Group, Protocol: snapshot.Protocol, Endpoint: snapshot.Endpoint, Model: snapshot.Model,
		Text: snapshot.ScanText, PromptHash: snapshot.PromptHash, MessageCount: snapshot.MessageCount,
		ConfigVersion: cfg.ConfigVersion, Stage: stage,
	}
	evaluator := currentPromptGuardEvaluator()
	var result gatewaycore.PromptGuardResult
	if synchronous, ok := evaluator.(*SynchronousEvaluator); ok {
		result = synchronous.evaluateWithConfig(c.Request.Context(), cfg, input)
	} else {
		result = evaluator.Evaluate(c.Request.Context(), input)
	}
	check.Result = result
	check.Allowed = result.AllowNextStage
	check.ErrorCode = result.ErrorCode
	if !check.Allowed {
		if result.Decision == gatewaycore.PromptGuardDecisionBlock {
			check.StatusCode = http.StatusForbidden
			check.ErrorCode = gatewaycore.PromptGuardErrorBlocked
		} else {
			check.StatusCode = http.StatusServiceUnavailable
			if check.ErrorCode == "" {
				check.ErrorCode = gatewaycore.PromptGuardErrorUnavailable
			}
		}
	}
	recordSynchronousResult(snapshot, cfg, result)
	return check
}

func promptGuardInputFailureFields(c *gin.Context, cfg Config, relayFormat types.RelayFormat, path string, stage string, reason string) []LogField {
	requestID := ""
	group := ""
	if c != nil {
		requestID = strings.TrimSpace(c.GetString(common.RequestIdKey))
		group = resolvePromptAuditRuntimeGroup(c)
	}
	status := "skipped"
	if strings.HasSuffix(strings.TrimSpace(reason), "_failed") {
		status = "failed"
	}
	return []LogField{
		Field("status", status),
		Field("reason", reason),
		Field("error_code", reason),
		Field("request_id", requestID),
		Field("group", group),
		Field("protocol", string(relayFormat)),
		Field("endpoint", strings.TrimSpace(path)),
		Field("config_version", normalizeConfigVersion(cfg.ConfigVersion)),
		Field("stage", stage),
		Field("upstream_dispatched", false),
		Field("billing_preconsumed", false),
	}
}

func promptGuardSnapshotContext(c *gin.Context) SnapshotContext {
	ctx := SnapshotContext{
		RequestID: strings.TrimSpace(c.GetString(common.RequestIdKey)),
		UserID:    common.GetContextKeyInt(c, constant.ContextKeyUserId),
		TokenID:   common.GetContextKeyInt(c, constant.ContextKeyTokenId),
		Group:     resolvePromptAuditRuntimeGroup(c),
	}
	if c.Request != nil {
		ctx.ContentType = c.Request.Header.Get("Content-Type")
	}
	return ctx
}

func recordSynchronousResult(snapshot PromptSnapshot, cfg Config, result gatewaycore.PromptGuardResult) {
	recordSynchronousResultWithSlots(snapshot, cfg, result, promptGuardRecordSlots)
}

func recordSynchronousResultWithSlots(snapshot PromptSnapshot, cfg Config, result gatewaycore.PromptGuardResult, recordSlots chan struct{}) {
	if result.Decision == gatewaycore.PromptGuardDecisionUnavailable || (result.Decision == gatewaycore.PromptGuardDecisionAllow && !cfg.StorePassEvents) {
		return
	}
	snapshot.ScanText = ""
	repo := defaultRepository
	select {
	case recordSlots <- struct{}{}:
	default:
		logSynchronousRecordFailure(snapshot, "record_queue_full", nil)
		return
	}
	go func(repo JobRepository, slots chan struct{}) {
		defer func() { <-slots }()
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if repo == nil || !repo.StorageSupported() {
			logSynchronousRecordFailure(snapshot, "storage_not_supported", errors.New("提示词审计存储不可用"))
			return
		}
		job := &appent.PromptAuditJob{
			ID: 0, RequestID: snapshot.RequestID, UserID: snapshot.UserID, TokenID: snapshot.TokenID,
			Endpoint: snapshot.Endpoint, Protocol: snapshot.Protocol, Model: snapshot.Model,
			ChannelID: snapshot.ChannelID, Group: snapshot.Group, PromptHash: snapshot.PromptHash,
			RedactedPreview: snapshot.RedactedPreview,
		}
		normalized := normalizedResultFromPromptGuard(result)
		if _, err := repo.CreateEvent(ctx, job, normalized); err != nil {
			logSynchronousRecordFailure(snapshot, "event_create_failed", err)
			return
		}
	}(repo, recordSlots)
}

func normalizedResultFromPromptGuard(result gatewaycore.PromptGuardResult) NormalizedResult {
	decision := DecisionPass
	risk := RiskLow
	if result.Decision == gatewaycore.PromptGuardDecisionFlag {
		decision = DecisionFlag
		risk = RiskHigh
	} else if result.Decision == gatewaycore.PromptGuardDecisionBlock {
		decision = DecisionCritical
		risk = RiskCritical
	}
	return NormalizedResult{
		Decision: decision, RiskLevel: risk, Categories: append([]string(nil), result.Categories...),
		MatchedScanners: append([]string(nil), result.MatchedScanners...), ScannerScores: cloneScannerScores(result.ScannerScores),
		ScannerBackend: result.ScannerBackend, ScannerVersion: result.ScannerVersion, Action: result.Action,
		PolicyID: result.PolicyID, PolicyVersion: result.PolicyVersion, LatencyMS: int(result.Latency.Milliseconds()),
		ScannerEvidence: ScannerEvidence{"_guard_observed_categories": promptGuardObservedCategoryEvidence(result.ObservedCategories)},
	}
}

func promptGuardObservedCategoryEvidence(categories []string) []ScannerEvidenceItem {
	items := make([]ScannerEvidenceItem, 0, len(categories))
	for _, category := range categories {
		if category = strings.TrimSpace(category); category != "" {
			items = append(items, ScannerEvidenceItem{ScannerID: category, Category: category, Kind: "classification"})
		}
	}
	return items
}

func logSynchronousRecordFailure(snapshot PromptSnapshot, code string, err error) {
	_ = err
	defaultPromptGuardMetrics.recordFailures.Add(1)
	LogWarnEvent("prompt_guard.result_record_failed",
		Field("status", "failed"), Field("request_id", snapshot.RequestID), Field("user_id", snapshot.UserID),
		Field("token_id", snapshot.TokenID), Field("group", snapshot.Group), Field("endpoint", snapshot.Endpoint),
		Field("error_code", code), Field("error_kind", code))
}

func HTTPGuardMiddleware(relayFormatHint ...types.RelayFormat) gin.HandlerFunc {
	return func(c *gin.Context) {
		if c == nil {
			return
		}
		if c.Request == nil || c.Request.Method == http.MethodGet || c.Request.Method == http.MethodHead {
			c.Next()
			return
		}
		relayFormat := resolvePromptGuardRelayFormat(c, relayFormatHint)
		cfg, cfgErr := loadCachedConfig(c.Request.Context())
		if cfgErr != nil {
			writePromptGuardHTTPError(c, relayFormat, http.StatusServiceUnavailable, gatewaycore.PromptGuardErrorUnavailable)
			c.Abort()
			return
		}
		if !cfg.Enabled || !cfg.BlockingEnabled {
			c.Next()
			return
		}
		body, err := common.GetRequestBody(c)
		if err != nil {
			LogWarnEvent("prompt_guard.failed", promptGuardInputFailureFields(c, cfg, relayFormat, requestPath(c), "http", "request_body_read_failed")...)
			writePromptGuardHTTPError(c, relayFormat, http.StatusServiceUnavailable, gatewaycore.PromptGuardErrorUnavailable)
			c.Abort()
			return
		}
		if len(body) == 0 {
			c.Next()
			return
		}
		path := ""
		if c.Request.URL != nil {
			path = c.Request.URL.Path
		}
		check := EvaluatePromptGuardBody(c, relayFormat, path, body, "http", false)
		if check.Enabled {
			c.Set(promptAuditEnqueueAttemptedKey, true)
		}
		if check.Allowed {
			c.Next()
			return
		}
		writePromptGuardHTTPError(c, relayFormat, check.StatusCode, check.ErrorCode)
		c.Abort()
	}
}

func resolvePromptGuardRelayFormat(c *gin.Context, relayFormatHint []types.RelayFormat) types.RelayFormat {
	if relayFormat := firstRelayFormatHint(relayFormatHint); relayFormat != "" {
		return relayFormat
	}
	return InferRelayFormatFromPath(requestPath(c))
}

func requestPath(c *gin.Context) string {
	if c == nil || c.Request == nil || c.Request.URL == nil {
		return ""
	}
	return c.Request.URL.Path
}

func writePromptGuardHTTPError(c *gin.Context, relayFormat types.RelayFormat, status int, code string) {
	if status == 0 {
		status = http.StatusServiceUnavailable
	}
	message := "提示词安全服务暂时不可用，请稍后重试"
	if code == gatewaycore.PromptGuardErrorBlocked {
		message = "请求因提示词安全策略被阻止"
	}
	requestID := c.GetString(common.RequestIdKey)
	switch relayFormat {
	case types.RelayFormatClaude:
		c.JSON(status, gin.H{"type": "error", "error": gin.H{"type": code, "message": message}, "request_id": requestID})
	case types.RelayFormatGemini:
		statusName := "UNAVAILABLE"
		if status == http.StatusForbidden {
			statusName = "PERMISSION_DENIED"
		}
		c.JSON(status, gin.H{"error": gin.H{"code": status, "message": message, "status": statusName, "details": []gin.H{{"reason": code, "request_id": requestID}}}})
	default:
		c.JSON(status, gin.H{"error": gin.H{"message": message, "type": "prompt_guard_error", "code": code, "request_id": requestID}})
	}
}
