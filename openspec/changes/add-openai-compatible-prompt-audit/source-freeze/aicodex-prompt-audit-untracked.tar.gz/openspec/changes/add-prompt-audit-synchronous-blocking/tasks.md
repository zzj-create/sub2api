## 1. 配置契约与运行时快照

- [x] 1.1 在提示词审计配置、保存请求、公开响应和前端类型中增加 `blocking_enabled`，旧配置缺失时归一为 `false`，并为非法组合返回 `prompt_guard_requires_audit_enabled`
- [x] 1.2 为提示词审计配置增加单调递增的 `config_version`、更新时间和脱敏变更摘要，补齐配置序列化、历史配置迁移和单元测试
- [x] 1.3 实现控制面保存后的本地缓存清理、Redis 失效通知和数据面原子只读快照，Redis 降级时输出 `prompt_guard.config_reload_degraded`
- [x] 1.4 扩展运行态接口，返回期望版本、生效版本、`blocking_enabled`、有效模式、最近加载时间和最近加载错误，并补控制器测试
- [x] 1.5 统一调度策略为有序 `priority` 故障切换，移除前端 `round_robin` 提交，对新保存请求中的未知策略返回校验错误，并为历史值迁移增加脱敏日志与测试

## 2. 同步门禁核心与 Guard 安全边界

- [x] 2.1 在 `gatewaycore` 定义不依赖 Gin、controller 和数据库的 Prompt Guard 输入、判定、错误和 evaluator 接口，明确 Allow/Flag/Block/Unavailable 契约
- [x] 2.2 抽取并复用现有协议提示词快照、最新输入优先和 Unicode 分片能力，保证同步与异步模式生成一致的 hash、预览和消息统计
- [x] 2.3 将 Qwen3Guard adapter 重构为“严格分类事实 → 服务端策略映射”，实现 Safe/Controversial/Unsafe、启用类别、`unknown_unsafe` 和未启用类别语义，并保持 `Controversial + Jailbreak|PII|Suicide & Self-Harm` 在对应类别启用时映射为 Block
- [x] 2.4 强化 Qwen3Guard 响应解析：限制正文大小、拒绝重复字段/额外说明/未知 Safety，并覆盖恶意回显、缺字段和多字段测试
- [x] 2.5 实现同步 evaluator 的共享总 deadline、最新分片优先、Block 早停、完整分片放行条件和 priority 节点故障切换，禁止部分结果组成 Allow
- [x] 2.6 为 Guard 出站 HTTP client 增加 scheme/地址/重定向校验、云元数据与 link-local 阻断、响应体上限、连接池、全局与每节点 bulkhead，并覆盖 SSRF 与容量饱和测试
- [x] 2.7 为同步 evaluator 增加 Safe、普通 Controversial Warn、高风险 Controversial Block、高风险类别关闭时 Warn、Unsafe Block、超时、429、5xx、401/403、非法响应、多节点故障切换和 context 取消单元测试

## 3. HTTP 数据面同步阻止接线

- [x] 3.1 在 `6068` 模型请求链路中把 Prompt Guard 放在鉴权/用户并发/速率限制之后、Distribute/PriorityAdmission/计费之前，关闭开关时保持现有异步投递路径
- [x] 3.2 在 `9068` OpenAI gateway adapter 中接入同一 evaluator，覆盖 `/v1/chat/completions`、`/v1/responses`、Responses alias、completions 和当前支持的文本入口
- [x] 3.3 在 `9068` Claude、Gemini 和文本任务 transport 中接入同一 evaluator，确保 GET/无文本请求按规格跳过且不形成 POST 旁路
- [x] 3.4 实现 OpenAI、Claude、Gemini 的协议错误映射：Block 返回 403/`prompt_guard_blocked`，Unavailable 与非法响应返回 503 和对应稳定错误码
- [x] 3.5 保证 SSE 在同步判定完成前不写响应头或首字节，并增加流式 Block/Unavailable 回归测试
- [x] 3.6 增加路由结构测试，枚举 `6068/9068` 受支持入口并断言同步门禁位于渠道选择、预扣和上游 dispatch 之前

## 4. Responses WebSocket 帧级门禁

- [x] 4.1 调整 Responses WebSocket 首轮顺序，在首个 `response.create` 的预扣费与上游拨号前执行同步 evaluator
- [x] 4.2 在连接存续期间拦截每个后续 `response.create`，在本轮预扣和客户端帧发送上游前执行同步 evaluator
- [x] 4.3 实现 WebSocket Block 的 `4403/prompt_guard_blocked` 和 Guard 故障的 `1013/prompt_guard_unavailable|prompt_guard_invalid_response` 映射
- [x] 4.4 增加首轮与后续轮次 Safe/Block/Unavailable 测试，断言被拒绝帧未发送上游且未创建对应 billing pending turn

## 5. 审计结果复用、日志与指标

- [x] 5.1 实现不携带原始提示词的同步结果记录路径，复用现有 Ent job/event 存储并确保同一请求不再次调用 Guard；如现有模型无法承载，先回写 design/specs 再调整 Ent Schema
- [x] 5.2 实现 `store_pass_events` 在同步模式下的通过事件语义，并覆盖 Block、Flag、Allow 和记录失败测试
- [x] 5.3 增加 `prompt_guard.config_updated|config_loaded|config_reload_degraded|evaluation_started|allowed|blocked|failed|result_record_failed` 结构化日志及稳定字段
- [x] 5.4 增加 Prompt Guard 判定分布、延迟、超时、非法响应、节点故障切换、bulkhead 饱和和结果记录失败指标
- [x] 5.5 增加日志脱敏测试，禁止提示词正文、API Key、Token、Authorization、完整 Guard URL 和内部优先分片边界进入日志、错误或事件

## 6. 控制台红框交互

- [x] 6.1 在 `webui` 配置 API、状态模型、默认配置、快照和保存 payload 中接入 `blocking_enabled` 与配置版本字段
- [x] 6.2 在提示词审计页底部保存栏的红框区域增加“同步阻止”开关，与“启用审计”“保留通过事件”并列，并提供关闭/开启模式说明
- [x] 6.3 实现开关联动：关闭审计时自动关闭并禁用同步阻止；开启同步阻止时展示 fail-closed 风险确认；修改只进入草稿并纳入脏状态、丢弃变更和统一保存
- [x] 6.4 在页面顶部与运行态区域展示“异步只审计/同步阻止”、期望版本、生效版本和 degraded 状态，禁止用未保存草稿冒充运行时生效状态
- [x] 6.5 更新提示词审计页面与 view model 测试，覆盖默认关闭、旧响应兼容、开关联动、确认取消、保存失败、丢弃修改和版本不一致展示
- [x] 6.6 补齐新增中文文案的 i18n 使用并验证页面不修改 `web/` 或引入新的前端依赖

## 7. 安全与协议验证

- [x] 7.1 建立良性、Unsafe、普通 Controversial、高风险 Controversial（Jailbreak/PII/Suicide & Self-Harm）、类别关闭、多语言、Unicode 混淆、提示词注入、长历史尾部风险和非法 Guard 输出回归语料
- [x] 7.2 使用 fake Guard 和 fake upstream 建立 `6068/9068 × OpenAI Chat/Responses/Claude/Gemini/文本任务 × HTTP/SSE` 集成矩阵
- [x] 7.3 对所有 Block 用例断言上游调用次数为 0、预扣次数为 0、渠道重试次数为 0，并验证错误响应不泄露具体提示词或 Guard 地址
- [x] 7.4 对关闭同步阻止的用例断言请求不等待 Guard、继续异步投递，队列或 Guard 故障不改变主请求结果
- [x] 7.5 执行 `cd ai-gateway && go test ./internal/service/promptaudit/... ./internal/gatewaycore/... ./internal/gatewayadapter/transport/... ./internal/relay/...` 和相关 controller/middleware 定向测试
- [x] 7.6 执行 `cd ai-gateway && go test -race` 的同步门禁关键包测试、`go test ./...` 与 `go build ./...`，修复数据竞争和编译回归
- [x] 7.7 执行 `cd webui && bun run lint`、`bun run eslint`、`bun run typecheck`、定向 Vitest 和 `bun run build`

## 8. 栈级验证、文档与工件回写

- [x] 8.1 更新 `docs/constraints/41-ai-readable-logging.md`，固化 Prompt Guard 事件名、字段、错误码、脱敏和 Block 副作用不变量
- [x] 8.2 更新 `docs/workflows/02-local-dev.md` 与相关运行手册，说明异步/同步双模式、Guard 依赖、灰度、故障排查和一键回滚
- [x] 8.3 如实现新增环境变量，同步更新 `deploy/.env.example` 和配置文档，并确保示例不包含真实密钥或生产 Guard 地址
- [x] 8.4 在仓库 `deploy/` 执行 `./build_image.sh`，再执行 `docker compose -p aicodex up -d`，验证 `6068/9068` 状态、同步 Allow/Block/Unavailable、Responses WebSocket 和结构化日志
- [x] 8.5 记录异步基线与同步模式的 P50/P95/P99、Block 率、Unavailable 率和 Guard 节点容量，未达到审核阈值时保持开关关闭
- [x] 8.6 若实现结论改变 fail-closed、WS 关闭行为、数据模型或控制面/数据面边界，先回写 proposal/design/specs 并重新提交审核
- [ ] 8.7 使用 OpenSpec 校验与变更验证流程确认所有 Requirement/Scenario、实现、测试和文档一致，审核通过前不得归档该 change
