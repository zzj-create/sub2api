package promptaudit

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const maxGuardResponseBytes int64 = 256 * 1024

type guardDialPolicyContextKey struct{}

type guardSecurityRoundTripper struct {
	base http.RoundTripper
}

func (r guardSecurityRoundTripper) RoundTrip(request *http.Request) (*http.Response, error) {
	if request == nil || request.URL == nil {
		return nil, errors.New("Guard 请求无效")
	}
	if err := validateGuardBaseURL(request.URL.String()); err != nil {
		return nil, err
	}
	allowPublicIP := strings.EqualFold(request.URL.Scheme, "https")
	clone := request.Clone(context.WithValue(request.Context(), guardDialPolicyContextKey{}, allowPublicIP))
	return r.base.RoundTrip(clone)
}

var blockedGuardHostnames = map[string]struct{}{
	"metadata.google.internal": {},
	"metadata.azure.internal":  {},
	"instance-data":            {},
}

func validateGuardBaseURL(raw string) error {
	parsed, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || parsed.Scheme == "" || parsed.Host == "" {
		return errors.New("OpenAI 兼容审计 Base URL 无效")
	}
	if parsed.User != nil {
		return errors.New("Guard Base URL 不允许包含用户名或密码")
	}
	if parsed.RawQuery != "" || parsed.Fragment != "" {
		return errors.New("Guard Base URL 不允许包含 query 或 fragment")
	}
	scheme := strings.ToLower(parsed.Scheme)
	if scheme != "http" && scheme != "https" {
		return errors.New("Guard Base URL 无效：仅允许 http 或 https")
	}
	host := strings.ToLower(strings.TrimSuffix(parsed.Hostname(), "."))
	if host == "" {
		return errors.New("Guard Base URL 缺少主机")
	}
	if _, blocked := blockedGuardHostnames[host]; blocked {
		return errors.New("Guard Base URL 指向受限元数据主机")
	}
	if ip := net.ParseIP(host); ip != nil {
		if isForbiddenGuardIP(ip) {
			return errors.New("Guard Base URL 指向 link-local、未指定或保留地址")
		}
		if scheme == "http" && !ip.IsLoopback() && !ip.IsPrivate() {
			return errors.New("公网 Guard Base URL 必须使用 HTTPS")
		}
		return nil
	}
	controlledInternalHost := !strings.Contains(host, ".") || strings.HasSuffix(host, ".localhost") || strings.HasSuffix(host, ".local") || strings.HasSuffix(host, ".internal")
	if scheme == "http" && host != "localhost" && !controlledInternalHost {
		return errors.New("HTTP Guard 仅允许 localhost 或显式私网 IP，公网与普通域名必须使用 HTTPS")
	}
	return nil
}

func isForbiddenGuardIP(ip net.IP) bool {
	if ip == nil {
		return true
	}
	return ip.IsUnspecified() || ip.IsMulticast() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast()
}

func newSecureGuardHTTPClient() *http.Client {
	dialer := &net.Dialer{Timeout: 5 * time.Second, KeepAlive: 30 * time.Second}
	transport := &http.Transport{
		ForceAttemptHTTP2:     true,
		MaxIdleConns:          100,
		MaxIdleConnsPerHost:   16,
		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   5 * time.Second,
		ResponseHeaderTimeout: 30 * time.Second,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			host, port, err := net.SplitHostPort(address)
			if err != nil {
				return nil, fmt.Errorf("解析 Guard 地址失败: %w", err)
			}
			ips, err := net.DefaultResolver.LookupIP(ctx, "ip", host)
			if err != nil {
				return nil, fmt.Errorf("解析 Guard 主机失败: %w", err)
			}
			var lastErr error
			allowPublicIP, _ := ctx.Value(guardDialPolicyContextKey{}).(bool)
			for _, ip := range ips {
				if isForbiddenGuardIP(ip) {
					lastErr = errors.New("Guard 主机解析到受限地址")
					continue
				}
				if !allowPublicIP && !ip.IsLoopback() && !ip.IsPrivate() {
					lastErr = errors.New("HTTP Guard 主机解析到公网地址")
					continue
				}
				conn, dialErr := dialer.DialContext(ctx, network, net.JoinHostPort(ip.String(), port))
				if dialErr == nil {
					return conn, nil
				}
				lastErr = dialErr
			}
			if lastErr == nil {
				lastErr = errors.New("Guard 主机没有可用地址")
			}
			return nil, lastErr
		},
	}
	return &http.Client{
		Transport: guardSecurityRoundTripper{base: transport},
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}
